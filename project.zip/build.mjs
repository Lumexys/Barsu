import { build } from "esbuild";
import fs from "fs";
fs.mkdirSync("www", { recursive: true });
fs.copyFileSync("src/index.html", "www/index.html");
await build({
  entryPoints: ["src/app.js"],
  bundle: true,
  format: "iife",
  outfile: "www/app.bundle.js",
  minify: true,
  target: "es2020"
});
console.log("bundle ok");
