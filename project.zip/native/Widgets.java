package by.barsu.student;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** Общие помощники для виджетов. */
final class Widgets {
    static PendingIntent open(Context c, String target, int code) {
        Intent i = new Intent(c, MainActivity.class);
        i.setAction(Intent.ACTION_MAIN);
        i.putExtra("open", target);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent bcast(Context c, Class<?> cls, String action, int widgetId, int code) {
        Intent i = new Intent(c, cls);
        i.setAction(action);
        i.setData(Uri.parse("barsu://widget/" + widgetId + "/" + action));
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void updateAll(Context c) {
        ScheduleWidget.updateAll(c);
        ScholarshipWidget.updateAll(c);
        TasksWidget.updateAll(c);
    }
}
