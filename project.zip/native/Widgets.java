package by.barsu.student;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;
import android.view.View;
import android.widget.RemoteViews;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Общие помощники для виджетов. */
public final class Widgets {
    static final String A_REFRESH = "by.barsu.student.WIDGET_REFRESH";

    static PendingIntent open(Context c, String target, int code) {
        // Свой action и уникальный адрес: иначе Android считает такой запуск обычным стартом
        // из лаунчера и не передаёт запущенному приложению, какой раздел открыть.
        Intent i = new Intent(c, MainActivity.class);
        i.setAction("by.barsu.student.OPEN");
        i.setData(Uri.parse("barsu://open/" + target));
        i.putExtra("open", target);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Кнопка «＋» в виджете заданий: окно быстрого добавления с файлами. */
    static PendingIntent quickAdd(Context c, int code) {
        Intent i = new Intent(c, QuickAddActivity.class);
        i.setAction("by.barsu.student.QUICK_ADD");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent bcast(Context c, Class<?> cls, String action, int widgetId, int code) {
        Intent i = new Intent(c, cls);
        i.setAction(action);
        i.setData(Uri.parse("barsu://widget/" + widgetId + "/" + action));
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /**
     * Обновление виджетов без сети и без открытого приложения: будильник примерно раз в полчаса и сразу после полуночи.
     * Не требует особых разрешений: время неточное, но достаточное для счётчиков и смены дня.
     */
    static void scheduleRefresh(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(c, Refresh.class);
            i.setAction(A_REFRESH);
            PendingIntent pi = PendingIntent.getBroadcast(c, 900, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Calendar mid = Calendar.getInstance();
            mid.add(Calendar.DAY_OF_YEAR, 1);
            mid.set(Calendar.HOUR_OF_DAY, 0);
            mid.set(Calendar.MINUTE, 0);
            mid.set(Calendar.SECOND, 5);
            mid.set(Calendar.MILLISECOND, 0);
            long t = Math.min(System.currentTimeMillis() + 30L * 60L * 1000L, mid.getTimeInMillis());
            am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi);
        } catch (Throwable t) {
            // ignore
        }
    }

    /** Разовое обновление в нужный момент (конец таймера, начало пары). Для каждого виджета свой код. */
    static void scheduleAt(Context c, long when, int code) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent i = new Intent(c, Refresh.class);
            i.setAction(A_REFRESH);
            PendingIntent pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC, when, pi);
        } catch (Throwable t) {
            // ignore
        }
    }

    static void updateAll(Context c) {
        scheduleRefresh(c);
        try { ScheduleWidget.updateAll(c); } catch (Throwable t) { /* ignore */ }
        try { ScholarshipWidget.updateAll(c); } catch (Throwable t) { /* ignore */ }
        try { TasksWidget.updateAll(c); } catch (Throwable t) { /* ignore */ }
        try { League.updateAll(c); } catch (Throwable t) { /* ignore */ }
        try { Pixel.updateAll(c); } catch (Throwable t) { /* ignore */ }
        try { Next.updateAll(c); } catch (Throwable t) { /* ignore */ }
    }

    /** Виджет «Лига факультетов». */
    public static class League extends AppWidgetProvider {
        @Override
        public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
            for (int id : ids) {
                try { m.updateAppWidget(id, GamesData.buildLeague(c)); } catch (Throwable t) { /* ignore */ }
            }
            scheduleRefresh(c);
        }

        static void updateAll(Context c) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, League.class));
            for (int id : ids) {
                try { m.updateAppWidget(id, GamesData.buildLeague(c)); } catch (Throwable t) { /* ignore */ }
            }
        }
    }

    /** Виджет «Следующая пара». */
    public static class Next extends AppWidgetProvider {
        @Override
        public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
            for (int id : ids) {
                try { m.updateAppWidget(id, GamesData.buildNext(c)); } catch (Throwable t) { /* ignore */ }
            }
            scheduleRefresh(c);
        }

        static void updateAll(Context c) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, Next.class));
            for (int id : ids) {
                try { m.updateAppWidget(id, GamesData.buildNext(c)); } catch (Throwable t) { /* ignore */ }
            }
        }
    }

    /** Виджет «Пиксель-батл». */
    public static class Pixel extends AppWidgetProvider {
        @Override
        public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
            for (int id : ids) {
                try { m.updateAppWidget(id, GamesData.buildPixel(c)); } catch (Throwable t) { /* ignore */ }
            }
            scheduleRefresh(c);
        }

        static void updateAll(Context c) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, Pixel.class));
            for (int id : ids) {
                try { m.updateAppWidget(id, GamesData.buildPixel(c)); } catch (Throwable t) { /* ignore */ }
            }
        }
    }

    /** Приёмник будильника: обновляет все виджеты и заводит следующий будильник. */
    public static class Refresh extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            updateAll(c);
        }
    }
}

/**
 * Данные игр для виджетов «Лига» и «Пиксель-батл». Сервер игр требует вход через Google, поэтому приложение один раз
 * передаёт сюда токен обновления (g_rt); дальше телефон сам получает короткий токен и запрашивает данные в фоне.
 */
final class GamesData {
    static final String SHA1 = "24392993E6EF06ADB7FFED0CD01D15642F7E0D12";
    static final int PX = 128;
    static final String[] IDS = {"if", "lf", "fpp", "fep"};
    static final String[] SHORT = {"ИФ", "ЛФ", "ФПП", "ФЭП"};
    static final String[] NAMES = {"Инженерный", "Лингвистический", "Педагогики и психологии", "Экономики и права"};
    static final int[] COLORS = {0xFFF08A24, 0xFFE5486D, 0xFF7A5CF6, 0xFF1FA971};

    private static int facIndex(String id) {
        for (int k = 0; k < IDS.length; k++) if (IDS[k].equals(id)) return k;
        return -1;
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private static String http(String method, String url, String body, String bearer, boolean androidKey) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setRequestMethod(method);
        h.setConnectTimeout(12000);
        h.setReadTimeout(20000);
        h.setRequestProperty("Accept", "application/json");
        if (androidKey) {
            h.setRequestProperty("X-Android-Package", "by.barsu.student");
            h.setRequestProperty("X-Android-Cert", SHA1);
        }
        if (bearer != null) h.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            OutputStream o = h.getOutputStream();
            o.write(body.getBytes("UTF-8"));
            o.close();
        }
        int code = h.getResponseCode();
        InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
        String s = in == null ? "" : read(in);
        h.disconnect();
        if (code >= 400) throw new Exception("HTTP " + code);
        return s;
    }

    private static String idToken(SharedPreferences sp) throws Exception {
        String cached = sp.getString("g_idt", "");
        if (!cached.isEmpty() && System.currentTimeMillis() < sp.getLong("g_idt_exp", 0)) return cached;
        String key = sp.getString("g_key", ""), rt = sp.getString("g_rt", "");
        String r = http("POST", "https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(key, "UTF-8"),
            "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(rt, "UTF-8"), null, true);
        JSONObject j = new JSONObject(r);
        String idt = j.getString("id_token");
        long ex = Long.parseLong(j.optString("expires_in", "3600"));
        SharedPreferences.Editor e = sp.edit().putString("g_idt", idt).putLong("g_idt_exp", System.currentTimeMillis() + (ex - 120) * 1000L);
        String nrt = j.optString("refresh_token", "");
        if (!nrt.isEmpty()) e.putString("g_rt", nrt);
        e.apply();
        return idt;
    }

    private static boolean has(Context c, Class<?> cls) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, cls)).length > 0;
    }

    /** Загружает данные лиги и полотна, если на экране есть такие виджеты. Вызывается из фоновой синхронизации. */
    static void refresh(Context c) {
        SharedPreferences sp = Store.p(c);
        if (sp.getString("g_rt", "").isEmpty() || sp.getString("g_key", "").isEmpty() || sp.getString("g_base", "").isEmpty()) return;
        boolean lg = has(c, Widgets.League.class), px = has(c, Widgets.Pixel.class);
        if (!lg && !px) return;
        try {
            String idt = idToken(sp), base = sp.getString("g_base", "");
            if (lg) {
                try {
                    String r = http("GET", base + "/api/g/league", null, idt, false);
                    new JSONObject(r);
                    sp.edit().putString("g_league", r).putLong("g_league_ts", System.currentTimeMillis()).apply();
                } catch (Exception e) {
                    if (String.valueOf(e.getMessage()).contains("401")) sp.edit().remove("g_idt").apply();
                }
            }
            if (px) {
                try {
                    String r = http("GET", base + "/api/g/pixel", null, idt, false);
                    new JSONObject(r);
                    sp.edit().putString("g_pixel", r).putLong("g_pixel_ts", System.currentTimeMillis()).apply();
                } catch (Exception e) {
                    if (String.valueOf(e.getMessage()).contains("401")) sp.edit().remove("g_idt").apply();
                }
            }
        } catch (Exception e) {
            // нет сети или токен отозван: покажем последние сохранённые данные
        }
    }

    private static JSONObject parse(String s) {
        try { return s == null || s.isEmpty() ? null : new JSONObject(s); } catch (Exception e) { return null; }
    }

    private static String left(long end) {
        long ms = end - System.currentTimeMillis();
        if (ms <= 0) return "скоро";
        long h = ms / 3600000L, d = h / 24;
        if (d >= 1) return d + " д " + (h % 24) + " ч";
        long m = (ms / 60000L) % 60;
        return h + " ч " + m + " мин";
    }

    private static CharSequence dot(int color, String text) {
        SpannableString sp = new SpannableString("■ " + text);
        sp.setSpan(new ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    static RemoteViews buildLeague(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_league);
        v.setOnClickPendingIntent(R.id.lg_root, Widgets.open(c, "league", 106));
        int[] N = {R.id.lg_n1, R.id.lg_n2, R.id.lg_n3, R.id.lg_n4};
        int[] P = {R.id.lg_p1, R.id.lg_p2, R.id.lg_p3, R.id.lg_p4};
        int[] D = {R.id.lg_d1, R.id.lg_d2, R.id.lg_d3, R.id.lg_d4};
        SharedPreferences sp = Store.p(c);
        JSONObject j = parse(sp.getString("g_league", ""));
        JSONArray facs = j == null ? null : j.optJSONArray("facs");
        if (facs == null || facs.length() == 0) {
            for (int k = 0; k < 4; k++) {
                v.setViewVisibility(N[k], View.GONE);
                v.setViewVisibility(P[k], View.GONE);
                v.setViewVisibility(D[k], View.GONE);
            }
            v.setViewVisibility(R.id.lg_msg, View.VISIBLE);
            v.setTextViewText(R.id.lg_msg, sp.getString("g_rt", "").isEmpty()
                ? "Откройте приложение и войдите через Google в разделе «Группа» или «Игры» — тогда здесь появится таблица."
                : "Данные лиги загружаются. Если долго пусто, проверьте интернет.");
            v.setTextViewText(R.id.lg_sub, "");
            return v;
        }
        v.setViewVisibility(R.id.lg_msg, View.GONE);
        JSONObject se = j.optJSONObject("season");
        String sub = se == null ? "" : se.optString("name", "");
        if (se != null && se.optLong("end", 0) > 0) sub += " · до " + new SimpleDateFormat("dd.MM", new Locale("ru")).format(new Date(se.optLong("end")));
        v.setTextViewText(R.id.lg_sub, sub);
        for (int k = 0; k < 4; k++) {
            JSONObject f = k < facs.length() ? facs.optJSONObject(k) : null;
            if (f == null) {
                v.setViewVisibility(N[k], View.GONE);
                v.setViewVisibility(P[k], View.GONE);
                v.setViewVisibility(D[k], View.GONE);
                continue;
            }
            int fi = facIndex(f.optString("id"));
            String sh = fi >= 0 ? SHORT[fi] : f.optString("id"), nm = fi >= 0 ? NAMES[fi] : "";
            int col = fi >= 0 ? COLORS[fi] : Color.GRAY;
            v.setViewVisibility(N[k], View.VISIBLE);
            v.setViewVisibility(P[k], View.VISIBLE);
            v.setTextViewText(N[k], dot(col, (k + 1) + ". " + sh + (nm.isEmpty() ? "" : " · " + nm)));
            v.setTextViewText(P[k], String.valueOf(f.optInt("total")));
            String det = "игры " + f.optInt("games") + " · пиксели " + f.optInt("pixel");
            JSONArray top = f.optJSONArray("top");
            if (top != null && top.length() > 0) {
                JSONObject t0 = top.optJSONObject(0);
                if (t0 != null) det += " · лучший: " + t0.optString("name") + " " + t0.optInt("pts");
            }
            v.setViewVisibility(D[k], View.VISIBLE);
            v.setTextViewText(D[k], det);
        }
        return v;
    }

    static RemoteViews buildPixel(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_pixel);
        v.setOnClickPendingIntent(R.id.px_root, Widgets.open(c, "pixel", 107));
        int[] S = {R.id.px_s1, R.id.px_s2, R.id.px_s3, R.id.px_s4};
        SharedPreferences sp = Store.p(c);
        JSONObject j = parse(sp.getString("g_pixel", ""));
        byte[] raw = null;
        try { if (j != null) raw = Base64.decode(j.optString("data", ""), Base64.DEFAULT); } catch (Exception e) { raw = null; }
        if (raw == null || raw.length < PX * PX) {
            for (int k = 0; k < 4; k++) v.setViewVisibility(S[k], View.GONE);
            v.setViewVisibility(R.id.px_img, View.GONE);
            v.setTextViewText(R.id.px_round, sp.getString("g_rt", "").isEmpty()
                ? "Откройте приложение и войдите через Google в разделе «Группа» или «Игры» — тогда здесь появится полотно."
                : "Полотно загружается. Если долго пусто, проверьте интернет.");
            v.setTextViewText(R.id.px_time, "");
            v.setTextViewText(R.id.px_cdl, "");
            v.setViewVisibility(R.id.px_cd, View.GONE);
            return v;
        }
        int[] px = new int[PX * PX];
        int[] cnt = new int[4];
        for (int k = 0; k < px.length; k++) {
            int b = raw[k] & 0xFF;
            if (b >= 1 && b <= 4) { px[k] = COLORS[b - 1]; cnt[b - 1]++; }
            else px[k] = 0xFFCFD6E2;
        }
        Bitmap small = Bitmap.createBitmap(px, PX, PX, Bitmap.Config.ARGB_8888);
        Bitmap big = Bitmap.createScaledBitmap(small, 256, 256, false);
        v.setViewVisibility(R.id.px_img, View.VISIBLE);
        v.setImageViewBitmap(R.id.px_img, big);
        List<Integer> order = new ArrayList<>();
        for (int k = 0; k < 4; k++) order.add(k);
        final int[] cc = cnt;
        java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return Integer.compare(cc[b], cc[a]);
            }
        });
        for (int k = 0; k < 4; k++) {
            int fi = order.get(k);
            double pc = cnt[fi] * 100.0 / (PX * PX);
            v.setViewVisibility(S[k], View.VISIBLE);
            v.setTextViewText(S[k], dot(COLORS[fi], SHORT[fi] + "  " + String.format(Locale.US, "%.1f", pc) + "%"));
        }
        v.setTextViewText(R.id.px_round, "Раунд " + j.optInt("round", 1));
        // таймер до следующей точки: «next» — сколько оставалось в момент загрузки
        long age = System.currentTimeMillis() - sp.getLong("g_pixel_ts", 0), rem = j.optLong("next", 0) - age;
        if (rem > 1000) {
            v.setTextViewText(R.id.px_cdl, "Следующая точка через");
            v.setViewVisibility(R.id.px_cd, View.VISIBLE);
            v.setChronometer(R.id.px_cd, SystemClock.elapsedRealtime() + rem, null, true);
            if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.px_cd, true);
            Widgets.scheduleAt(c, System.currentTimeMillis() + rem + 1500, 901);
        } else {
            v.setTextViewText(R.id.px_cdl, "Можно ставить точку ✓");
            v.setViewVisibility(R.id.px_cd, View.GONE);
        }
        long end = j.optLong("end", 0);
        v.setTextViewText(R.id.px_time, end > 0 ? "до конца: " + left(end) : "");
        return v;
    }

    static RemoteViews buildNext(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_next);
        v.setOnClickPendingIntent(R.id.nx_root, Widgets.open(c, "sched", 108));
        Calendar nowC = Calendar.getInstance();
        int mm = nowC.get(Calendar.HOUR_OF_DAY) * 60 + nowC.get(Calendar.MINUTE);
        if (Store.follow(c) == null) {
            v.setTextViewText(R.id.nx_when, "");
            v.setTextViewText(R.id.nx_title, "Откройте приложение → Расписание → «Сделать моим расписанием».");
            v.setTextViewText(R.id.nx_aud, "");
            v.setTextViewText(R.id.nx_cdl, "");
            v.setViewVisibility(R.id.nx_cd, View.GONE);
            return v;
        }
        for (int off = 0; off < 8; off++) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, off);
            JSONArray items = Store.lessonsFor(c, Store.ymd(cal));
            if (items == null) continue;
            List<ScheduleWidget.Row> list = new ArrayList<>();
            for (int k = 0; k < items.length(); k++) {
                JSONObject o = items.optJSONObject(k);
                if (o == null) continue;
                ScheduleWidget.Row r = ScheduleWidget.rowOf(o, "");
                if (r != null) list.add(r);
            }
            java.util.Collections.sort(list, new java.util.Comparator<ScheduleWidget.Row>() {
                @Override
                public int compare(ScheduleWidget.Row a, ScheduleWidget.Row b) {
                    return Integer.compare(a.s, b.s);
                }
            });
            for (ScheduleWidget.Row r : list) {
                if (off == 0 && mm >= r.e) continue;
                boolean going = off == 0 && mm >= r.s;
                String day = off == 0 ? "Сегодня" : off == 1 ? "Завтра" : new SimpleDateFormat("EEE, d MMMM", new Locale("ru")).format(cal.getTime());
                String t = hmm(r.s) + "–" + hmm(r.e);
                v.setTextViewText(R.id.nx_when, going ? "Идёт сейчас · до " + hmm(r.e) : day + " · " + t);
                v.setTextViewText(R.id.nx_title, r.text);
                v.setTextViewText(R.id.nx_aud, r.a.isEmpty() ? "" : "Аудитория: " + r.a);
                long sec = nowC.get(Calendar.SECOND);
                long ms = going ? ((r.e - mm) * 60L - sec) * 1000L : ((r.s - mm) * 60L - sec) * 1000L + off * 86400000L;
                if (ms > 1000) {
                    v.setTextViewText(R.id.nx_cdl, going ? "До конца пары" : "До начала");
                    v.setViewVisibility(R.id.nx_cd, View.VISIBLE);
                    v.setChronometer(R.id.nx_cd, SystemClock.elapsedRealtime() + ms, null, true);
                    if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.nx_cd, true);
                    Widgets.scheduleAt(c, System.currentTimeMillis() + Math.min(ms, 6L * 3600000L) + 1500, 902);
                } else {
                    v.setTextViewText(R.id.nx_cdl, "");
                    v.setViewVisibility(R.id.nx_cd, View.GONE);
                }
                return v;
            }
        }
        v.setTextViewText(R.id.nx_when, "");
        v.setTextViewText(R.id.nx_title, "Ближайших пар нет 🎉");
        v.setTextViewText(R.id.nx_aud, "");
        v.setTextViewText(R.id.nx_cdl, "");
        v.setViewVisibility(R.id.nx_cd, View.GONE);
        return v;
    }

    private static String hmm(int m) {
        return (m / 60) + ":" + (m % 60 < 10 ? "0" : "") + (m % 60);
    }
}
