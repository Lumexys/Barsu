package by.barsu.student;

import android.appwidget.AppWidgetManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import java.io.File;
import java.io.OutputStream;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

/** Мост между страницей и нативной частью: общие данные, виджеты, фоновая синхронизация. */
@CapacitorPlugin(name = "BarsuNative")
public class BarsuNative extends Plugin {
    static String launch = null;

    static void setLaunch(Intent i) {
        if (i != null && i.hasExtra("open")) {
            launch = i.getStringExtra("open");
            i.removeExtra("open"); // чтобы пересоздание окна не открывало раздел повторно
        }
    }

    @PluginMethod
    public void setFollow(PluginCall call) {
        Store.setFollow(getContext(), call.getString("json", "{}"));
        Widgets.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void clearFollow(PluginCall call) {
        Store.clearFollow(getContext());
        Widgets.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void setLessons(PluginCall call) {
        try {
            Store.mergeLessons(getContext(), new JSONObject(call.getString("json", "{}")), System.currentTimeMillis());
            Widgets.updateAll(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void getLessons(PluginCall call) {
        JSObject r = new JSObject();
        r.put("lessons", Store.lessonsPlain(getContext()).toString());
        call.resolve(r);
    }

    @PluginMethod
    public void setTasks(PluginCall call) {
        long ts = Store.setTasks(getContext(), call.getString("json", "[]"));
        TasksWidget.updateAll(getContext());
        JSObject r = new JSObject();
        r.put("ts", ts);
        call.resolve(r);
    }

    @PluginMethod
    public void getTasks(PluginCall call) {
        JSObject r = new JSObject();
        r.put("json", Store.tasks(getContext()).toString());
        r.put("ts", Store.tasksTs(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void syncNow(final PluginCall call) {
        final Context c = getContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSObject r = new JSObject();
                try {
                    r.put("weeks", Sync.run(c, false));
                } catch (Exception e) {
                    r.put("error", String.valueOf(e.getMessage()));
                }
                try {
                    Widgets.updateAll(c);
                } catch (Exception e) {
                    // ignore
                }
                call.resolve(r);
            }
        }).start();
    }

    @PluginMethod
    public void scheduleSync(PluginCall call) {
        SyncWorker.schedule(getContext());
        call.resolve();
    }

    @PluginMethod
    public void pendingPath(PluginCall call) {
        String id = call.getString("id", "").replaceAll("[^A-Za-z0-9_-]", "");
        File f = new File(new File(getContext().getFilesDir(), "pending"), id);
        if (id.isEmpty() || !f.exists()) {
            call.reject("none");
            return;
        }
        JSObject r = new JSObject();
        r.put("path", f.getAbsolutePath());
        call.resolve(r);
    }

    @PluginMethod
    public void deletePending(PluginCall call) {
        String id = call.getString("id", "").replaceAll("[^A-Za-z0-9_-]", "");
        if (!id.isEmpty()) new File(new File(getContext().getFilesDir(), "pending"), id).delete();
        call.resolve();
    }

    @PluginMethod
    public void consumeLaunch(PluginCall call) {
        JSObject r = new JSObject();
        r.put("target", launch == null ? "" : launch);
        launch = null;
        call.resolve(r);
    }

    /** Данные группы для фоновых уведомлений о новых записях. */
    @PluginMethod
    public void setGroupInfo(PluginCall call) {
        android.content.SharedPreferences.Editor e = Store.p(getContext()).edit();
        String gid = call.getString("gid", "");
        if (gid.isEmpty()) {
            e.remove("n_gid").remove("n_sub").remove("n_last");
        } else {
            String old = Store.p(getContext()).getString("n_gid", "");
            e.putString("n_gid", gid).putString("n_uid", call.getString("uid", "")).putString("n_sub", call.getString("sub", "")).putString("n_pid", call.getString("pid", ""));
            if (!gid.equals(old)) e.remove("n_last");
        }
        e.apply();
        call.resolve();
    }

    /** Приложение передаёт данные для входа в сервер игр, чтобы виджеты лиги и пиксель-батла обновлялись сами. */
    @PluginMethod
    public void setGamesAuth(PluginCall call) {
        final Context c = getContext();
        String rt = call.getString("rt", ""), key = call.getString("key", ""), base = call.getString("base", "");
        android.content.SharedPreferences.Editor e = Store.p(c).edit();
        if (rt.isEmpty()) {
            e.remove("g_rt").remove("g_idt").remove("g_league").remove("g_pixel");
        } else {
            e.putString("g_rt", rt).putString("g_key", key).putString("g_base", base);
        }
        e.apply();
        call.resolve();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    GamesData.refresh(c);
                    Widgets.updateAll(c);
                } catch (Throwable t) {
                    // ignore
                }
            }
        }).start();
    }

    // ===== Запись расписания в календарь телефона (появляется и в Google Календаре, если он синхронизируется) =====
    private static BarsuNative inst;
    private static PluginCall calCall;
    private String calName = "";

    @Override
    public void load() { inst = this; }

    @PluginMethod
    public void calendarAdd(PluginCall call) {
        Context c = getContext();
        if (c.checkSelfPermission(android.Manifest.permission.WRITE_CALENDAR) == android.content.pm.PackageManager.PERMISSION_GRANTED
            && c.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            doCalendar(call);
            return;
        }
        calCall = call;
        androidx.core.app.ActivityCompat.requestPermissions(getActivity(), new String[] {android.Manifest.permission.READ_CALENDAR, android.Manifest.permission.WRITE_CALENDAR}, 7771);
    }

    static void onCalendarPermission(int[] res) {
        PluginCall call = calCall;
        calCall = null;
        if (call == null || inst == null) return;
        boolean ok = res.length > 0;
        for (int r : res) if (r != android.content.pm.PackageManager.PERMISSION_GRANTED) ok = false;
        if (ok) { inst.doCalendar(call); return; }
        JSObject o = new JSObject();
        o.put("state", "denied");
        call.resolve(o);
    }

    private long pickCalendar(android.content.ContentResolver cr) {
        long best = -1;
        int bestScore = -1;
        android.database.Cursor cur = cr.query(android.provider.CalendarContract.Calendars.CONTENT_URI,
            new String[] {android.provider.CalendarContract.Calendars._ID, android.provider.CalendarContract.Calendars.ACCOUNT_TYPE, android.provider.CalendarContract.Calendars.IS_PRIMARY,
                android.provider.CalendarContract.Calendars.VISIBLE, android.provider.CalendarContract.Calendars.CALENDAR_DISPLAY_NAME},
            android.provider.CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + ">=500", null, null);
        if (cur == null) return -1;
        try {
            while (cur.moveToNext()) {
                int score = ("com.google".equals(cur.getString(1)) ? 4 : 0) + (cur.getInt(2) == 1 ? 2 : 0) + (cur.getInt(3) == 1 ? 1 : 0);
                if (score > bestScore) { bestScore = score; best = cur.getLong(0); calName = cur.getString(4) == null ? "" : cur.getString(4); }
            }
        } finally {
            cur.close();
        }
        return best;
    }

    private void doCalendar(final PluginCall call) {
        final Context c = getContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSObject r = new JSObject();
                try {
                    android.content.ContentResolver cr = c.getContentResolver();
                    long calId = pickCalendar(cr);
                    if (calId < 0) { r.put("state", "nocal"); call.resolve(r); return; }
                    com.getcapacitor.JSArray evs = call.getArray("events");
                    long mn = Long.MAX_VALUE, mx = 0;
                    for (int i = 0; i < evs.length(); i++) { org.json.JSONObject e = evs.getJSONObject(i); mn = Math.min(mn, e.getLong("s")); mx = Math.max(mx, e.getLong("e")); }
                    // прежняя выгрузка за этот же период заменяется, чтобы пары не дублировались
                    cr.delete(android.provider.CalendarContract.Events.CONTENT_URI,
                        android.provider.CalendarContract.Events.DESCRIPTION + " LIKE ? AND " + android.provider.CalendarContract.Events.CALENDAR_ID + "=? AND "
                            + android.provider.CalendarContract.Events.DTSTART + ">=? AND " + android.provider.CalendarContract.Events.DTSTART + "<=?",
                        new String[] {"%[barsu-student]%", String.valueOf(calId), String.valueOf(mn - 60000), String.valueOf(mx + 60000)});
                    String tz = java.util.TimeZone.getDefault().getID();
                    int n = 0;
                    for (int i = 0; i < evs.length(); i++) {
                        org.json.JSONObject e = evs.getJSONObject(i);
                        android.content.ContentValues v = new android.content.ContentValues();
                        v.put(android.provider.CalendarContract.Events.CALENDAR_ID, calId);
                        v.put(android.provider.CalendarContract.Events.TITLE, e.optString("t"));
                        v.put(android.provider.CalendarContract.Events.DTSTART, e.getLong("s"));
                        v.put(android.provider.CalendarContract.Events.DTEND, e.getLong("e"));
                        v.put(android.provider.CalendarContract.Events.EVENT_TIMEZONE, tz);
                        v.put(android.provider.CalendarContract.Events.EVENT_LOCATION, e.optString("l"));
                        v.put(android.provider.CalendarContract.Events.DESCRIPTION, e.optString("d") + "\n[barsu-student]");
                        v.put(android.provider.CalendarContract.Events.HAS_ALARM, 1);
                        Uri u = cr.insert(android.provider.CalendarContract.Events.CONTENT_URI, v);
                        if (u == null) continue;
                        n++;
                        android.content.ContentValues rm = new android.content.ContentValues();
                        rm.put(android.provider.CalendarContract.Reminders.EVENT_ID, Long.parseLong(u.getLastPathSegment()));
                        rm.put(android.provider.CalendarContract.Reminders.MINUTES, 10);
                        rm.put(android.provider.CalendarContract.Reminders.METHOD, android.provider.CalendarContract.Reminders.METHOD_ALERT);
                        cr.insert(android.provider.CalendarContract.Reminders.CONTENT_URI, rm);
                    }
                    r.put("state", "ok");
                    r.put("n", n);
                    r.put("cal", calName);
                } catch (Exception ex) {
                    r.put("state", "error");
                }
                call.resolve(r);
            }
        }).start();
    }

    /** «Назад» на главном экране: убираем приложение в фон, как это делают обычные приложения. */
    @PluginMethod
    public void exitApp(PluginCall call) {
        try { getActivity().moveTaskToBack(true); } catch (Exception e) { /* ignore */ }
        call.resolve();
    }

    /** Установленная версия приложения. */
    @PluginMethod
    public void appVersion(PluginCall call) {
        try {
            Context c = getContext();
            android.content.pm.PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            JSObject r = new JSObject();
            r.put("code", Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
            r.put("name", pi.versionName == null ? "" : pi.versionName);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("version");
        }
    }

    /** Скачивает новую версию и открывает установщик Android. */
    @PluginMethod
    public void installUpdate(PluginCall call) {
        final Context c = getContext().getApplicationContext();
        String url = call.getString("url", "");
        if (url.isEmpty()) { call.reject("no url"); return; }
        try {
            JSObject r = new JSObject();
            if (Build.VERSION.SDK_INT >= 26 && !c.getPackageManager().canRequestPackageInstalls()) {
                Intent s = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.getPackageName()));
                s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(s);
                r.put("state", "permission");
                call.resolve(r);
                return;
            }
            File dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            final File f = new File(dir, "update.apk");
            if (f.exists()) f.delete();
            android.app.DownloadManager dm = (android.app.DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
            android.app.DownloadManager.Request rq = new android.app.DownloadManager.Request(Uri.parse(url));
            rq.setTitle("Студенту БарГУ: обновление");
            rq.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            rq.setDestinationUri(Uri.fromFile(f));
            final long id = dm.enqueue(rq);
            android.content.BroadcastReceiver rc = new android.content.BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent in) {
                    if (in.getLongExtra(android.app.DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                    try { ctx.unregisterReceiver(this); } catch (Exception e) { /* ignore */ }
                    try {
                        Uri u = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(u, "application/vnd.android.package-archive");
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        ctx.startActivity(i);
                    } catch (Exception e) {
                        // установщик не открылся: файл остался в загрузках приложения
                    }
                }
            };
            android.content.IntentFilter fl = new android.content.IntentFilter(android.app.DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(rc, fl, Context.RECEIVER_EXPORTED);
            else c.registerReceiver(rc, fl);
            r.put("state", "downloading");
            call.resolve(r);
        } catch (Exception e) {
            call.reject("install");
        }
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        String n = call.getString("name", "");
        Class<?> cls = "schedule".equals(n) ? ScheduleWidget.class
            : "scholarship".equals(n) ? ScholarshipWidget.class
            : "next".equals(n) ? Widgets.Next.class
            : "league".equals(n) ? Widgets.League.class
            : "pixel".equals(n) ? Widgets.Pixel.class
            : "tasks".equals(n) ? TasksWidget.class : null;
        boolean ok = false;
        if (cls != null && Build.VERSION.SDK_INT >= 26) {
            try {
                AppWidgetManager m = AppWidgetManager.getInstance(getContext());
                if (m.isRequestPinAppWidgetSupported()) {
                    ok = m.requestPinAppWidget(new ComponentName(getContext(), cls), null, null);
                }
            } catch (Exception e) {
                ok = false;
            }
        }
        JSObject r = new JSObject();
        r.put("ok", ok);
        call.resolve(r);
    }

    /** Сохраняет файл в общую папку «Загрузки» (Android 10+ без дополнительных разрешений). */
    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        if (Build.VERSION.SDK_INT < 29) {
            call.reject("old_android");
            return;
        }
        try {
            String name = call.getString("name", "file");
            String mime = call.getString("mime", "application/octet-stream");
            byte[] data = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
            ContentResolver cr = getContext().getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            v.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) {
                call.reject("insert_failed");
                return;
            }
            OutputStream os = cr.openOutputStream(u);
            if (os == null) {
                call.reject("stream_failed");
                return;
            }
            try {
                os.write(data);
            } finally {
                os.close();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            cr.update(u, done, null, null);
            String shown = name;
            android.database.Cursor cur = cr.query(u, new String[] {MediaStore.Downloads.DISPLAY_NAME}, null, null, null);
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) shown = cur.getString(0);
                } finally {
                    cur.close();
                }
            }
            JSObject r = new JSObject();
            r.put("uri", u.toString());
            r.put("name", shown);
            call.resolve(r);
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void openFile(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(call.getString("uri", "")), call.getString("mime", "*/*"));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (ActivityNotFoundException e) {
            call.reject("no_app");
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }
}
