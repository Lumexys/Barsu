package by.barsu.student;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

/** Мост между страницей и нативной частью: общие данные, виджеты, фоновая синхронизация. */
@CapacitorPlugin(name = "BarsuNative")
public class BarsuNative extends Plugin {
    static String launch = null;

    static void setLaunch(Intent i) {
        if (i != null && i.hasExtra("open")) launch = i.getStringExtra("open");
    }

    @PluginMethod
    public void setFollow(PluginCall call) {
        Store.setFollow(getContext(), call.getString("json", "{}"));
        Widgets.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void clearFollow(PluginCall call) {
        Store.clearFollow(getContext());
        Widgets.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void setLessons(PluginCall call) {
        try {
            Store.mergeLessons(getContext(), new JSONObject(call.getString("json", "{}")), System.currentTimeMillis());
            Widgets.updateAll(getContext());
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void getLessons(PluginCall call) {
        JSObject r = new JSObject();
        r.put("lessons", Store.lessonsPlain(getContext()).toString());
        call.resolve(r);
    }

    @PluginMethod
    public void setTasks(PluginCall call) {
        long ts = Store.setTasks(getContext(), call.getString("json", "[]"));
        TasksWidget.updateAll(getContext());
        JSObject r = new JSObject();
        r.put("ts", ts);
        call.resolve(r);
    }

    @PluginMethod
    public void getTasks(PluginCall call) {
        JSObject r = new JSObject();
        r.put("json", Store.tasks(getContext()).toString());
        r.put("ts", Store.tasksTs(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void syncNow(final PluginCall call) {
        final Context c = getContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSObject r = new JSObject();
                try {
                    r.put("weeks", Sync.run(c, false));
                } catch (Exception e) {
                    r.put("error", String.valueOf(e.getMessage()));
                }
                try {
                    Widgets.updateAll(c);
                } catch (Exception e) {
                    // ignore
                }
                call.resolve(r);
            }
        }).start();
    }

    @PluginMethod
    public void scheduleSync(PluginCall call) {
        SyncWorker.schedule(getContext());
        call.resolve();
    }

    @PluginMethod
    public void consumeLaunch(PluginCall call) {
        JSObject r = new JSObject();
        r.put("target", launch == null ? "" : launch);
        launch = null;
        call.resolve(r);
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        String n = call.getString("name", "");
        Class<?> cls = "schedule".equals(n) ? ScheduleWidget.class
            : "scholarship".equals(n) ? ScholarshipWidget.class
            : "tasks".equals(n) ? TasksWidget.class : null;
        boolean ok = false;
        if (cls != null && Build.VERSION.SDK_INT >= 26) {
            try {
                AppWidgetManager m = AppWidgetManager.getInstance(getContext());
                if (m.isRequestPinAppWidgetSupported()) {
                    ok = m.requestPinAppWidget(new ComponentName(getContext(), cls), null, null);
                }
            } catch (Exception e) {
                ok = false;
            }
        }
        JSObject r = new JSObject();
        r.put("ok", ok);
        call.resolve(r);
    }
}
