package by.barsu.student;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.concurrent.TimeUnit;

public class SyncWorker extends Worker {
    public SyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        try {
            Sync.run(c, true);
        } catch (Throwable t) {
            // сеть недоступна или сайт не ответил — попробуем в следующий раз
        }
        try {
            NoteSync.run(c);
        } catch (Throwable t) {
            // ignore
        }
        try {
            GamesData.refresh(c);
        } catch (Throwable t) {
            // ignore
        }
        try {
            Widgets.updateAll(c);
        } catch (Throwable t) {
            // ignore
        }
        return Result.success();
    }

    static void schedule(Context c) {
        Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest r = new PeriodicWorkRequest.Builder(SyncWorker.class, 15, TimeUnit.MINUTES)
            .setConstraints(cons)
            .build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("barsu-sync", ExistingPeriodicWorkPolicy.KEEP, r);
    }
}

/** Фоновая проверка новых записей группы: читает Firestore по REST с правами самого пользователя и показывает уведомление. */
final class NoteSync {
    private static String post(String url, String json, String bearer) throws Exception {
        java.net.HttpURLConnection h = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        h.setRequestMethod("POST");
        h.setConnectTimeout(12000);
        h.setReadTimeout(20000);
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/json");
        h.setRequestProperty("Authorization", "Bearer " + bearer);
        java.io.OutputStream o = h.getOutputStream();
        o.write(json.getBytes("UTF-8"));
        o.close();
        int code = h.getResponseCode();
        java.io.InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        if (in != null) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        }
        h.disconnect();
        if (code >= 400) throw new Exception("HTTP " + code);
        return bo.toString("UTF-8");
    }

    private static long ts(String v) {
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return f.parse(v.substring(0, 19)).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    private static String str(org.json.JSONObject f, String k) {
        org.json.JSONObject x = f.optJSONObject(k);
        return x == null ? "" : x.optString("stringValue", "");
    }

    static void run(Context c) throws Exception {
        android.content.SharedPreferences sp = Store.p(c);
        String gid = sp.getString("n_gid", ""), uid = sp.getString("n_uid", ""), pid = sp.getString("n_pid", ""), sub = sp.getString("n_sub", "");
        if (gid.isEmpty() || pid.isEmpty() || sp.getString("g_rt", "").isEmpty()) return;
        String idt = GamesData.idToken(sp);
        String q = "{\"structuredQuery\":{\"from\":[{\"collectionId\":\"posts\"}],\"orderBy\":[{\"field\":{\"fieldPath\":\"ts\"},\"direction\":\"DESCENDING\"}],\"limit\":15}}";
        String base = "https://firestore.googleapis.com/v1/projects/" + pid + "/databases/(default)/documents/groups/" + gid;
        String[] roots = sub.isEmpty() ? new String[] {base} : new String[] {base, base + "/subs/" + sub};
        long last = sp.getLong("n_last", 0), max = last;
        java.util.List<String[]> fresh = new java.util.ArrayList<String[]>();
        for (String root : roots) {
            org.json.JSONArray arr = new org.json.JSONArray(post(root + ":runQuery", q, idt));
            for (int k = 0; k < arr.length(); k++) {
                org.json.JSONObject d = arr.optJSONObject(k) == null ? null : arr.optJSONObject(k).optJSONObject("document");
                if (d == null) continue;
                org.json.JSONObject f = d.optJSONObject("fields");
                if (f == null) continue;
                long t = ts(f.optJSONObject("ts") == null ? "" : f.optJSONObject("ts").optString("timestampValue", ""));
                if (t <= 0) continue;
                if (t > max) max = t;
                boolean del = f.optJSONObject("deleted") != null && f.optJSONObject("deleted").optBoolean("booleanValue", false);
                if (t > last && !del && !str(f, "authorUid").equals(uid)) fresh.add(new String[] {str(f, "type"), str(f, "subject"), str(f, "text"), str(f, "authorName")});
            }
        }
        sp.edit().putLong("n_last", max > 0 ? max : System.currentTimeMillis()).apply();
        if (last == 0 || fresh.isEmpty()) return;      // первый запуск: просто запоминаем время, чтобы не засыпать старыми записями
        if (android.os.Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        android.app.NotificationManager nm = (android.app.NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new android.app.NotificationChannel("group", "Записи группы", android.app.NotificationManager.IMPORTANCE_DEFAULT));
        String title, body;
        if (fresh.size() == 1) {
            String[] p = fresh.get(0);
            title = "hw".equals(p[0]) ? "📚 Новое домашнее задание" : "change".equals(p[0]) ? "🔔 Изменение в группе" : "📝 Новая заметка в группе";
            body = (p[1].isEmpty() ? "" : p[1] + ": ") + p[2] + (p[3].isEmpty() ? "" : " — " + p[3]);
        } else {
            title = "Новых записей в группе: " + fresh.size();
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < fresh.size() && k < 4; k++) sb.append(k > 0 ? "\n" : "").append("• ").append(fresh.get(k)[1].isEmpty() ? "" : fresh.get(k)[1] + ": ").append(fresh.get(k)[2]);
            body = sb.toString();
        }
        if (body.length() > 300) body = body.substring(0, 300) + "…";
        android.app.Notification.Builder nb = android.os.Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(c, "group") : new android.app.Notification.Builder(c);
        nb.setSmallIcon(R.drawable.ic_stat_note).setContentTitle(title).setContentText(body.split("\n")[0]).setStyle(new android.app.Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(Widgets.open(c, "group", 110));
        nm.notify(880002, nb.build());
    }
}
