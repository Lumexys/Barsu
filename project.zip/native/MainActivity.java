package by.barsu.student;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.getcapacitor.BridgeActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    // ===== ВРЕМЕННО: журнал сбоев. Чтобы убрать, верните прежний MainActivity.java и уберите <activity> CrashActivity из patch_android.py =====
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        try { installCrashLog(base); } catch (Throwable t) { /* ignore */ }
    }

    static void installCrashLog(final Context c) {
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    String s = "Поток: " + t.getName() + "\n" + Log.getStackTraceString(e);
                    Log.e("BarsuCrash", s);
                    FileOutputStream o = new FileOutputStream(new File(c.getFilesDir(), "last_crash.txt"));
                    o.write(s.getBytes("UTF-8"));
                    o.close();
                    Intent i = new Intent(c, CrashActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    c.startActivity(i);
                    Thread.sleep(700);
                } catch (Throwable x) { /* ignore */ }
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(10);
            }
        });
    }

    // Отдельный экран в отдельном процессе (:crash), поэтому он открывается, даже если основное приложение упало
    public static class CrashActivity extends Activity {
        private String full = "";
        private TextView tv;

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(24, 64, 24, 24);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            Button copy = new Button(this); copy.setText("Копировать");
            Button share = new Button(this); share.setText("Отправить");
            Button close = new Button(this); close.setText("Закрыть");
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(copy, bp); row.addView(share, bp); row.addView(close, bp);
            ScrollView sv = new ScrollView(this);
            tv = new TextView(this);
            tv.setTypeface(Typeface.MONOSPACE);
            tv.setTextSize(11);
            tv.setTextIsSelectable(true);
            tv.setText("Собираем лог…");
            sv.addView(tv);
            root.addView(row);
            root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            setContentView(root);
            copy.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("log", full));
                        tv.append("\n\n[Скопировано]");
                    } catch (Throwable t) { /* ignore */ }
                }
            });
            share.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, full);
                        startActivity(Intent.createChooser(i, "Отправить лог"));
                    } catch (Throwable t) { /* ignore */ }
                }
            });
            close.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { finish(); }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    final String s = build();
                    runOnUiThread(new Runnable() {
                        @Override public void run() { full = s; tv.setText(s); }
                    });
                }
            }).start();
        }

        private String build() {
            StringBuilder sb = new StringBuilder();
            SimpleDateFormat f = new SimpleDateFormat("dd.MM HH:mm:ss", Locale.US);
            sb.append("Устройство: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
              .append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
            sb.append("Сейчас: ").append(f.format(new Date())).append("\n");
            // 1. Исключение Java, записанное при сбое
            try {
                File cf = new File(getFilesDir(), "last_crash.txt");
                if (cf.exists()) {
                    byte[] buf = new byte[(int) Math.min(cf.length(), 12000)];
                    FileInputStream in = new FileInputStream(cf);
                    int n = in.read(buf); in.close();
                    sb.append("\n=== ИСКЛЮЧЕНИЕ (").append(f.format(new Date(cf.lastModified()))).append(") ===\n")
                      .append(new String(buf, 0, Math.max(n, 0), "UTF-8")).append("\n");
                }
            } catch (Throwable t) { sb.append("\n[не удалось прочитать файл сбоя: ").append(t).append("]\n"); }
            // 2. Причины последних завершений процесса (Android 11+)
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                    List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(getPackageName(), 0, 6);
                    sb.append("\n=== ПОСЛЕДНИЕ ЗАВЕРШЕНИЯ ===\n");
                    for (ApplicationExitInfo x : l) {
                        sb.append(f.format(new Date(x.getTimestamp()))).append("  ")
                          .append(reason(x.getReason())).append("  статус=").append(x.getStatus())
                          .append("  процесс=").append(x.getProcessName()).append("\n");
                        String d = x.getDescription();
                        if (d != null && d.length() > 0) sb.append("   ").append(d).append("\n");
                    }
                } catch (Throwable t) { sb.append("\n[завершения недоступны: ").append(t).append("]\n"); }
            }
            // 3. Системный лог только этого приложения (предупреждения и ошибки)
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-v", "time", "-t", "1500"});
                BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                ArrayList<String> keep = new ArrayList<String>();
                String line;
                while ((line = r.readLine()) != null) {
                    if (line.contains(" E/") || line.contains(" F/") || line.contains(" W/") || line.contains("FATAL")
                        || line.contains("signal") || line.contains("Capacitor") || line.contains("BarsuCrash")) {
                        keep.add(line.length() > 300 ? line.substring(0, 300) : line);
                    }
                }
                r.close();
                int from = Math.max(0, keep.size() - 120);
                sb.append("\n=== LOGCAT (последние ").append(keep.size() - from).append(") ===\n");
                for (int i = from; i < keep.size(); i++) sb.append(keep.get(i)).append("\n");
            } catch (Throwable t) { sb.append("\n[logcat недоступен: ").append(t).append("]\n"); }
            return sb.toString();
        }

        private static String reason(int r) {
            switch (r) {
                case 1: return "EXIT_SELF";
                case 2: return "SIGNALED";
                case 3: return "LOW_MEMORY";
                case 4: return "CRASH (Java)";
                case 5: return "CRASH_NATIVE";
                case 6: return "ANR";
                case 7: return "INITIALIZATION_FAILURE";
                case 8: return "PERMISSION_CHANGE";
                case 9: return "EXCESSIVE_RESOURCE_USAGE";
                case 10: return "USER_REQUESTED";
                case 11: return "USER_STOPPED";
                case 12: return "DEPENDENCY_DIED";
                case 13: return "OTHER";
                default: return "UNKNOWN(" + r + ")";
            }
        }
    }
    // ===== конец временного журнала сбоев =====

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(BarsuHttp.class);
        registerPlugin(BarsuNative.class);
        super.onCreate(savedInstanceState);
        BarsuNative.setLaunch(getIntent());
        try {
            SyncWorker.schedule(this);
        } catch (Throwable t) {
            // ignore
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        BarsuNative.setLaunch(intent);
    }
}
