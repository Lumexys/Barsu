package by.barsu.student;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(BarsuHttp.class);
        registerPlugin(BarsuNative.class);
        super.onCreate(savedInstanceState);
        BarsuNative.setLaunch(getIntent());
        try {
            SyncWorker.schedule(this);
        } catch (Throwable t) {
            // ignore
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        BarsuNative.setLaunch(intent);
    }
}
