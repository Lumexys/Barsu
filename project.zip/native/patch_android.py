import re, sys

# --- манифест: разрешения и виджеты ---
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
perms = """
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
"""
def receiver(cls, res, label):
    return f"""
        <receiver android:name="by.barsu.student.{cls}" android:exported="false" android:label="{label}">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE"/>
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/{res}"/>
        </receiver>"""
recv = (receiver("ScheduleWidget", "widget_schedule_info", "Расписание на день")
        + receiver("ScholarshipWidget", "widget_scholarship_info", "Таймер до стипендии")
        + receiver("TasksWidget", "widget_tasks_info", "Домашка и дедлайны") + "\n    ")
assert "</application>" in s and "</manifest>" in s
s = s.replace("</application>", recv + "</application>", 1)
s = s.replace("</manifest>", perms + "</manifest>", 1)
open(p, "w", encoding="utf-8").write(s)

# --- gradle: WorkManager и jsoup ---
g = "android/app/build.gradle"
t = open(g, encoding="utf-8").read()
dep = '\n    implementation "androidx.work:work-runtime:2.9.0"\n    implementation "org.jsoup:jsoup:1.17.2"'
t2, n = re.subn(r"^dependencies \{", "dependencies {" + dep, t, count=1, flags=re.M)
assert n == 1, "dependencies block not found"
open(g, "w", encoding="utf-8").write(t2)
print("android patched")
