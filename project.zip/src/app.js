import JSZip from "jszip";
import { Capacitor, registerPlugin } from "@capacitor/core";
import { LocalNotifications as LN } from "@capacitor/local-notifications";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { installApi } from "./api.js";

window.JSZip = JSZip;
const NATIVE = Capacitor.isNativePlatform();
const Native = registerPlugin("BarsuNative");
installApi();

const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};
const pad2 = n => String(n).padStart(2, "0");
const fmt = m => Math.floor(m / 60) + ":" + pad2(m % 60);
const selKey = s => !s ? "" : (s.k === "stud" ? "s|" + s.fac + "|" + s.spec + "|" + s.grp : "t|" + s.teacher);
const $id = id => document.getElementById(id);

// ---------- «моё расписание»: пары для виджетов и напоминаний ----------
function lessonsMap(days, parseT) {
  const res = {};
  days.forEach(d => {
    const list = [];
    d.grp.forEach(g => {
      const t = parseT(g.time);
      if (!t) return;
      const aud = g.its.map(x => x.b.find(z => /ауд/i.test(z))).find(Boolean) || "";
      list.push({ s: t.s, e: t.e, t: g.its.map(x => x.b[0]).join(" / "), a: aud });
    });
    res[d.date] = list;
  });
  return res;
}

async function ensureChannel() {
  try { await LN.createChannel({ id: "lessons", name: "Напоминания о парах", importance: 4, vibration: true }); } catch (e) {}
}
async function cancelAll() {
  try {
    const p = await LN.getPending();
    if (p.notifications.length) await LN.cancel({ notifications: p.notifications.map(n => ({ id: n.id })) });
  } catch (e) {}
}
async function askPermissions() {
  const p = await LN.requestPermissions();
  if (p.display !== "granted") return false;
  try {
    const s = await LN.checkExactNotificationSetting();
    if (s.exact_alarm !== "granted") await LN.changeExactNotificationSetting();
  } catch (e) {}
  return true;
}

// Напоминания строятся из общего хранилища: туда пишут и страница, и фоновая синхронизация.
async function rescheduleFromNative() {
  const f = LS.get("notif_follow", null);
  if (!NATIVE || !f) return;
  let map = {};
  try { const r = await Native.getLessons(); map = JSON.parse(r.lessons || "{}"); } catch (e) { return; }
  await cancelAll();
  const now = Date.now(), lead = f.lead * 60000, list = [];
  Object.keys(map).forEach(date => {
    const [y, m, d] = date.split("-").map(Number);
    (map[date] || []).forEach(it => {
      const at = new Date(y, m - 1, d, Math.floor(it.s / 60), it.s % 60).getTime();
      if (at - lead > now + 5000) list.push({ at, title: it.t, body: fmt(it.s) + "–" + fmt(it.e) + (it.a ? " · " + it.a : "") });
    });
  });
  list.sort((a, b) => a.at - b.at);
  const items = list.slice(0, 150).map(l => ({
    id: Math.floor(l.at / 60000) % 2000000000,
    title: "Через " + f.lead + " мин: " + l.title,
    body: l.body,
    channelId: "lessons",
    schedule: { at: new Date(l.at - lead), allowWhileIdle: true }
  }));
  if (items.length) { try { await LN.schedule({ notifications: items }); } catch (e) {} }
}

function buildRow(out, days, parseT, sel) {
  const f = LS.get("notif_follow", null), mine = f && f.key === selKey(sel);
  const row = document.createElement("div");
  row.className = "bellrow";
  row.style.cssText = "margin:12px 0;display:flex;flex-direction:column;gap:8px";
  const btn = document.createElement("button");
  btn.className = "nb";
  btn.type = "button";
  const hint = document.createElement("div");
  hint.className = "hint";
  const refresh = () => { row.remove(); buildRow(out, days, parseT, sel); };
  if (mine) {
    btn.textContent = "🔕 Отключить «моё расписание»";
    btn.onclick = async () => {
      LS.set("notif_follow", null);
      try { await Native.clearFollow(); } catch (e) {}
      await cancelAll();
      refresh();
    };
    const lead = document.createElement("select");
    [5, 10, 15, 30, 60].forEach(n => {
      const o = document.createElement("option");
      o.value = n; o.textContent = "Напоминать за " + n + " мин до пары";
      if (n === f.lead) o.selected = true;
      lead.appendChild(o);
    });
    lead.onchange = async () => {
      f.lead = +lead.value;
      LS.set("notif_follow", f);
      try { await Native.setFollow({ json: JSON.stringify(f) }); } catch (e) {}
      await rescheduleFromNative();
      refresh();
    };
    row.append(btn, lead);
    hint.textContent = "Включены напоминания о парах, виджеты и уведомления об изменениях в расписании. Данные обновляются в фоне.";
  } else {
    btn.textContent = "📌 Сделать моим расписанием";
    btn.onclick = async () => {
      btn.disabled = true;
      hint.textContent = "Настраиваем…";
      try {
        if (!(await askPermissions())) {
          hint.textContent = "Разрешите уведомления для приложения в настройках телефона.";
          btn.disabled = false;
          return;
        }
        await ensureChannel();
        const b = Object.assign({}, window.__BODY || {});
        delete b.week;
        const nf = Object.assign({ key: selKey(sel), label: sel.label, lead: 15 }, b);
        LS.set("notif_follow", nf);
        await Native.setFollow({ json: JSON.stringify(nf) });
        await Native.setLessons({ json: JSON.stringify(lessonsMap(days, parseT)) });
        await Native.syncNow();
        await rescheduleFromNative();
        await Native.scheduleSync();
      } catch (e) {
        hint.textContent = "Не удалось включить: " + (e && e.message ? e.message : e);
        btn.disabled = false;
        return;
      }
      refresh();
    };
    row.appendChild(btn);
    hint.textContent = f
      ? "Сейчас «моё расписание»: " + f.label + ". Нажатие заменит его."
      : "Включит напоминания о парах, виджеты на рабочий стол и уведомления, когда расписание меняется.";
  }
  row.appendChild(hint);
  out.appendChild(row);
}

async function afterRender(days, parseT, sel) {
  if (!NATIVE || !sel) return;
  const out = $id("sOut");
  if (!out || !out.querySelector(".day")) return;
  const old = out.querySelector(".bellrow");
  if (old) old.remove();
  const f = LS.get("notif_follow", null);
  if (f && f.key === selKey(sel)) {
    try {
      await Native.setLessons({ json: JSON.stringify(lessonsMap(days, parseT)) });
      rescheduleFromNative();
    } catch (e) {}
  }
  if (!out.querySelector(".bellrow")) buildRow(out, days, parseT, sel);
}

// ---------- задания: общее хранилище со страницей и виджетом ----------
function rerenderTasks() {
  const tool = $id("mTool"), more = $id("p_more");
  if (tool && more && !tool.classList.contains("hide") && !more.classList.contains("hide")
      && document.querySelector("#mBody input[placeholder='Что нужно сделать']") && window.openTool) {
    window.openTool("tasks");
  }
}
async function pullTasks() {
  try {
    const r = await Native.getTasks();
    const lts = +localStorage.getItem("app_tasks_ts") || 0;
    if (r.ts > lts) {
      localStorage.setItem("tasks", r.json);
      localStorage.setItem("app_tasks_ts", String(r.ts));
      rerenderTasks();
    } else if (r.ts === 0) {
      const cur = localStorage.getItem("tasks");
      if (cur && cur !== "[]") {
        const s = await Native.setTasks({ json: cur });
        localStorage.setItem("app_tasks_ts", String(s.ts));
      }
    }
  } catch (e) {}
}
function onSet(k, v) {
  if (!NATIVE || k !== "tasks") return;
  Native.setTasks({ json: JSON.stringify(v) })
    .then(r => { try { localStorage.setItem("app_tasks_ts", String(r.ts)); } catch (e) {} })
    .catch(() => {});
}

// ---------- переходы из виджетов и уведомлений ----------
async function launchTarget() {
  try {
    const r = await Native.consumeLaunch();
    const t = r && r.target;
    if (!t) return;
    if (t === "tasks" && window.showTab && window.openTool) { window.showTab("more"); window.openTool("tasks"); }
    else if (t === "sched" && window.showTab) window.showTab("sched");
  } catch (e) {}
}
async function onResume() {
  if (!NATIVE) return;
  await pullTasks();
  await launchTarget();
  await rescheduleFromNative();
}

// ---------- сохранение файлов ----------
const asciiName = n => n.replace(/[^\w.\-]+/g, "_");
async function writeAndShare(data, name, opts) {
  let r;
  try {
    r = await Filesystem.writeFile(Object.assign({ path: name, data, directory: Directory.Cache }, opts));
  } catch (e) {
    r = await Filesystem.writeFile(Object.assign({ path: asciiName(name), data, directory: Directory.Cache }, opts));
  }
  await Share.share({ title: name, url: r.uri, dialogTitle: "Сохранить или отправить" });
}
async function saveFile(blob, name) {
  try {
    const b64 = await new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result).split(",")[1]);
      fr.onerror = () => rej(fr.error);
      fr.readAsDataURL(blob);
    });
    await writeAndShare(b64, name, {});
    return true;
  } catch (e) {
    if (e && /cancel/i.test(String(e.message || e))) return true;
    return false;
  }
}
async function saveIcs(text, name) {
  try {
    await writeAndShare(text, name, { encoding: Encoding.UTF8 });
  } catch (e) {
    if (e && /cancel/i.test(String(e.message || e))) return;
    const m = $id("sMsg");
    if (m) m.textContent = "Не удалось сохранить файл календаря.";
  }
}
async function pinWidget(name) {
  try { const r = await Native.pinWidget({ name }); return !!(r && r.ok); } catch (e) { return false; }
}

window.AppNative = { isNative: NATIVE, afterRender, saveIcs, saveFile, pinWidget, onSet };

if (NATIVE) {
  const hide = () => { const b = $id("shBtn"); if (b) b.style.display = "none"; };
  document.addEventListener("DOMContentLoaded", hide);
  hide();
  ensureChannel();
  window.addEventListener("load", () => {
    const f = LS.get("notif_follow", null);
    if (f) Native.setFollow({ json: JSON.stringify(f) }).catch(() => {});
    Native.scheduleSync().catch(() => {});
    onResume();
  });
  document.addEventListener("visibilitychange", () => { if (!document.hidden) onResume(); });
}
