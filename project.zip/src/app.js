import JSZip from "jszip";
import { Capacitor } from "@capacitor/core";
import { LocalNotifications as LN } from "@capacitor/local-notifications";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { installApi } from "./api.js";

window.JSZip = JSZip;
const NATIVE = Capacitor.isNativePlatform();
installApi();

const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};
const pad2 = n => String(n).padStart(2, "0");
const fmt = m => Math.floor(m / 60) + ":" + pad2(m % 60);
const selKey = s => !s ? "" : (s.k === "stud" ? "s|" + s.fac + "|" + s.spec + "|" + s.grp : "t|" + s.teacher);
const ymdOf = d => d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());

// ---------- напоминания о парах ----------
function lessonsOf(days, parseT) {
  const res = {};
  days.forEach(d => {
    const list = [];
    d.grp.forEach(g => {
      const t = parseT(g.time);
      if (!t) return;
      const [y, m, dd] = d.date.split("-").map(Number);
      const at = new Date(y, m - 1, dd, Math.floor(t.s / 60), t.s % 60).getTime();
      const aud = g.its.map(x => x.b.find(z => /ауд/i.test(z))).find(Boolean);
      list.push({
        at,
        title: g.its.map(x => x.b[0]).join(" / "),
        body: fmt(t.s) + "–" + fmt(t.e) + (aud ? " · " + aud : "")
      });
    });
    res[d.date] = list;
  });
  return res;
}

async function ensureChannel() {
  try { await LN.createChannel({ id: "lessons", name: "Напоминания о парах", importance: 4, vibration: true }); } catch (e) {}
}
async function cancelAll() {
  try {
    const p = await LN.getPending();
    if (p.notifications.length) await LN.cancel({ notifications: p.notifications.map(n => ({ id: n.id })) });
  } catch (e) {}
}
async function reschedule() {
  const f = LS.get("notif_follow", null);
  if (!f) return;
  await cancelAll();
  const store = LS.get("notif_les", {}), now = Date.now(), lead = f.lead * 60000, list = [];
  Object.keys(store).forEach(date => store[date].forEach(l => { if (l.at - lead > now + 5000) list.push(l); }));
  list.sort((a, b) => a.at - b.at);
  const items = list.slice(0, 150).map(l => ({
    id: Math.floor(l.at / 60000) % 2000000000,
    title: "Через " + f.lead + " мин: " + l.title,
    body: l.body,
    channelId: "lessons",
    schedule: { at: new Date(l.at - lead), allowWhileIdle: true }
  }));
  if (items.length) await LN.schedule({ notifications: items });
}
async function askPermissions() {
  const p = await LN.requestPermissions();
  if (p.display !== "granted") return false;
  try {
    const s = await LN.checkExactNotificationSetting();
    if (s.exact_alarm !== "granted") await LN.changeExactNotificationSetting();
  } catch (e) {}
  return true;
}
function saveStore(days, parseT) {
  const store = LS.get("notif_les", {}), fresh = lessonsOf(days, parseT), today = ymdOf(new Date(Date.now() - 86400000));
  Object.assign(store, fresh);
  Object.keys(store).forEach(k => { if (k < today) delete store[k]; });
  LS.set("notif_les", store);
}

function buildRow(out, days, parseT, sel) {
  const f = LS.get("notif_follow", null), mine = f && f.key === selKey(sel);
  const row = document.createElement("div");
  row.className = "bellrow";
  row.style.cssText = "margin:12px 0;display:flex;flex-direction:column;gap:8px";
  const btn = document.createElement("button");
  btn.className = "nb";
  btn.type = "button";
  const hint = document.createElement("div");
  hint.className = "hint";
  if (mine) {
    btn.textContent = "🔕 Выключить напоминания";
    btn.onclick = async () => { LS.set("notif_follow", null); LS.set("notif_les", {}); await cancelAll(); refresh(); };
    const lead = document.createElement("select");
    [5, 10, 15, 30, 60].forEach(n => {
      const o = document.createElement("option");
      o.value = n; o.textContent = "За " + n + " мин до пары";
      if (n === f.lead) o.selected = true;
      lead.appendChild(o);
    });
    lead.onchange = async () => { f.lead = +lead.value; LS.set("notif_follow", f); await reschedule(); refresh(); };
    row.append(btn, lead);
    hint.textContent = "Напоминания включены. Они обновляются при каждом открытии приложения.";
  } else {
    btn.textContent = "🔔 Напоминать о парах";
    btn.onclick = async () => {
      if (!(await askPermissions())) { hint.textContent = "Разрешите уведомления для приложения в настройках телефона."; return; }
      await ensureChannel();
      LS.set("notif_follow", { key: selKey(sel), label: sel.label, lead: 15 });
      LS.set("notif_les", {});
      saveStore(days, parseT);
      await reschedule();
      refresh();
    };
    row.appendChild(btn);
    hint.textContent = f ? "Сейчас напоминания идут для: " + f.label + ". Включение здесь заменит их." : "Уведомление придёт за 15 минут до начала каждой пары.";
  }
  row.appendChild(hint);
  out.appendChild(row);
  function refresh() { row.remove(); buildRow(out, days, parseT, sel); }
}

function afterRender(days, parseT, sel) {
  if (!NATIVE || !sel) return;
  const out = document.getElementById("sOut");
  if (!out || !out.querySelector(".day")) return;
  const old = out.querySelector(".bellrow");
  if (old) old.remove();
  const f = LS.get("notif_follow", null);
  if (f && f.key === selKey(sel)) {
    saveStore(days, parseT);
    reschedule().catch(() => {});
  }
  buildRow(out, days, parseT, sel);
}

// ---------- экспорт .ics через «Поделиться» ----------
async function saveIcs(text, name) {
  try {
    const r = await Filesystem.writeFile({ path: name, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
    await Share.share({ title: name, url: r.uri, dialogTitle: "Добавить в календарь" });
  } catch (e) {
    const m = document.getElementById("sMsg");
    if (m) m.textContent = "Не удалось сохранить файл календаря.";
  }
}

window.AppNative = { isNative: NATIVE, afterRender, saveIcs };

// В приложении нет публичной ссылки, поэтому «Поделиться» скрываем.
if (NATIVE) {
  const hide = () => { const b = document.getElementById("shBtn"); if (b) b.style.display = "none"; };
  document.addEventListener("DOMContentLoaded", hide);
  hide();
  ensureChannel();
}
