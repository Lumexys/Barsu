/* ===== Карточные игры ===== */
/* --- Цвета (как Уно) --- */
const UNO_C = { r: '#e63946', y: '#f4b400', g: '#2a9d5c', b: '#1f6fd1', w: '#222' }, UNO_N = { r: 'красный', y: 'жёлтый', g: 'зелёный', b: 'синий' };
function unoEl(c, o = {}) {
  const lbl = { skip: '⊘', rev: '⇄', '+2': '+2', wild: '★', '+4': '+4' }[c.v] || c.v;
  const e = h('div', { style: { width: (o.w || 52) + 'px', height: Math.round((o.w || 52) * 1.45) + 'px', borderRadius: '9px', background: UNO_C[c.c], border: '3px solid #fff', boxShadow: o.sel ? '0 0 0 3px #f5c400' : '0 2px 5px rgba(0,0,0,.3)', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 800, fontSize: Math.round((o.w || 52) * .42) + 'px', fontFamily: 'var(--f-num)', flex: 'none', opacity: o.dim ? .45 : 1, cursor: o.onclick ? 'pointer' : 'default', textShadow: '0 2px 0 rgba(0,0,0,.25)' } },
    c.c === 'w' ? h('div', { style: { width: '62%', aspectRatio: 1, borderRadius: '50%', background: 'conic-gradient(#e63946 0 25%,#f4b400 0 50%,#2a9d5c 0 75%,#1f6fd1 0)', display: 'grid', placeItems: 'center', fontSize: '.7em' } }, c.v === '+4' ? '+4' : '') : lbl);
  if (o.onclick) e.addEventListener('click', o.onclick);
  return e;
}
game({
  id: 'uno', name: 'Цвета', like: 'похоже на Уно', cat: 'cards', icon: '🎴', c1: '#e63946', c2: '#1f6fd1', players: '2–4 игрока',
  rules: ['Кладите карту того же цвета или того же значения, что сверху.', '⊘ — следующий пропускает ход, ⇄ — меняет направление, +2 — следующий берёт 2 карты и пропускает ход.', '★ — выбрать цвет. +4 — выбрать цвет, следующий берёт 4.', 'Нет подходящей карты — возьмите одну из колоды. Первым избавился от всех карт — победил.', 'С ботом играют четверо, на одном телефоне — двое, онлайн — от двух до четырёх.'],
  run(el, ctx) {
    const net = ctx.net, on = !!net, hot = ctx.mode === 'hot', myName = G.me && G.me.name || 'Вы';
    const deck = []; ['r', 'y', 'g', 'b'].forEach(c => { deck.push({ c, v: '0' }); for (let k = 0; k < 2; k++) { for (let n = 1; n <= 9; n++) deck.push({ c, v: '' + n }); ['skip', 'rev', '+2'].forEach(v => deck.push({ c, v })); } });
    for (let k = 0; k < 4; k++) { deck.push({ c: 'w', v: 'wild' }); deck.push({ c: 'w', v: '+4' }); }
    shuffle(deck);
    const P = on ? net.seats.map(s => ({ n: s.name + (net.isMe(s) ? ' (вы)' : ''), bot: !!s.bot })) : hot ? [{ n: 'Игрок 1' }, { n: 'Игрок 2' }] : [{ n: myName }, { n: 'Бот Вася', bot: 1 }, { n: 'Бот Оля', bot: 1 }, { n: 'Бот Петя', bot: 1 }];
    P.forEach(p => p.h = deck.splice(0, 7));
    let top; do { top = deck.shift(); if (top.c === 'w') deck.push(top); } while (top.c === 'w');
    let pile = [], color = top.c, turn = 0, dir = 1, drew = false, viewer = 0, over = false, msg = '';
    const autoSeat = i => on ? (P[i].bot || net.seats[i].left) : P[i].bot; // за этого игрока ходит программа
    const mine = i => on ? net.seat === i : hot ? true : !P[i].bot;
    const draw1 = p => { if (!deck.length) { deck.push(...shuffle(pile)); pile = []; } if (!deck.length) return; p.h.push(deck.pop()); };
    const ok = c => c && (c.c === 'w' || c.c === color || c.v === top.v);
    const felt = h('div', { class: 'felt' }), hand = h('div', { class: 'hand' }), ctl = h('div', { class: 'bar2' });
    el.append(felt, hand, ctl);
    const nextI = (k = 1) => (turn + dir * k + P.length * 4) % P.length;
    const finishWin = pi => {
      over = true; render();
      if (on) ctx.ranks(P.map((p, i) => i === pi ? 0 : 1), P[pi].n + ' побеждает');
      else if (hot) ctx.match('draw', P[pi].n + ' победил!'); else ctx.match(pi === 0 ? 'win' : 'loss', pi === 0 ? 'Победа!' : P[pi].n + ' победил');
    };
    const play = (pi, card, chosen) => {
      const p = P[pi]; p.h.splice(p.h.indexOf(card), 1); pile.push(top); top = card; color = card.c === 'w' ? chosen : card.c; drew = false;
      msg = p.n + ': ' + (card.c === 'w' ? 'цвет — ' + UNO_N[color] : 'ход сделан');
      if (!p.h.length) { finishWin(pi); return; }
      if (p.h.length === 1) ctx.toast(p.n + ': «Последняя!»', 1200);
      if (card.v === 'rev') { dir *= -1; if (P.length === 2) turn = nextI(); }
      if (card.v === 'skip') turn = nextI();
      if (card.v === '+2') { const t = P[nextI()]; draw1(t); draw1(t); turn = nextI(); }
      if (card.v === '+4') { const t = P[nextI()]; for (let k = 0; k < 4; k++) draw1(t); turn = nextI(); }
      turn = nextI(); step();
    };
    // все действия: {p: номер карты в руке, c: цвет} — сыграть, {d:1} — взять, {s:1} — пропустить после взятия
    const apply = (i, a) => {
      if (over || i !== turn) return;
      const p = P[i];
      if (a.p != null) { const card = p.h[a.p]; if (!ok(card)) return; if (card.c === 'w' && !UNO_N[a.c]) return; play(i, card, a.c); return; }
      if (a.d && !drew) {
        draw1(p); drew = true;
        if (!ok(p.h[p.h.length - 1])) { msg = p.n + ': карта не подошла, ход переходит'; drew = false; turn = nextI(); render(); ctx.later(step, 600); return; }
        msg = mine(i) ? 'Можно сыграть взятую карту или пропустить ход' : p.n + ' взял(а) карту'; render(); if (autoSeat(i)) step(); return;
      }
      if (a.s && drew) { drew = false; turn = nextI(); step(); }
    };
    const act = a => { if (on) net.send(a); else apply(turn, a); };
    if (on) net.onAct((s, a) => apply(s, a));
    const step = () => {
      if (over) return;
      const p = P[turn];
      if (autoSeat(turn)) { render(); if (!on || net.isHost) { const i = turn; ctx.later(() => { if (turn === i && !over) botMove(i); }, 750); } return; }
      if (hot && viewer !== turn) { viewer = turn; render(true); passScreen(el, p.n, () => render()); return; }
      if (!on) viewer = turn;
      msg = (mine(turn) ? (hot ? p.n + ', ваш ход' : 'Ваш ход') : 'Ходит ' + p.n) + ' · цвет: ' + UNO_N[color]; render();
    };
    const botMove = i => {
      const p = P[i], k = p.h.findIndex(c => c.c !== 'w' && ok(c)), k2 = k >= 0 ? k : p.h.findIndex(ok);
      const cnt = {}; p.h.forEach(x => x.c !== 'w' && (cnt[x.c] = (cnt[x.c] || 0) + 1));
      const best = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0]?.[0] || 'r';
      const a = k2 >= 0 ? { p: k2, c: best } : drew ? { s: 1 } : { d: 1 };
      if (on) net.botSend(i, a); else apply(i, a);
    };
    const chooseColor = idx => { ctl.innerHTML = ''; ['r', 'y', 'g', 'b'].forEach(c => ctl.append(h('button', { class: 'nb', type: 'button', style: { background: UNO_C[c], color: '#fff' }, onclick: () => act({ p: idx, c }) }, UNO_N[c]))); };
    const render = (hide) => {
      if (on) viewer = Math.max(0, net.seat);
      felt.innerHTML = '';
      const opp = h('div', { style: { display: 'flex', gap: '14px', flexWrap: 'wrap', justifyContent: 'center' } });
      P.forEach((p, i) => { if (i === viewer && !p.bot) return; opp.append(h('div', { class: 'seat' + (i === turn ? ' turn' : '') }, h('span', { class: 'av' }, p.bot ? '🤖' : '🙂'), h('span', null, p.n, h('br'), h('small', null, p.h.length + ' карт')))); });
      felt.append(opp, h('div', { style: { display: 'flex', gap: '18px', alignItems: 'center' } },
        h('div', { style: { width: '52px', height: '75px', borderRadius: '9px', background: 'repeating-linear-gradient(45deg,#222 0 6px,#444 6px 12px)', border: '3px solid #fff', cursor: 'pointer', display: 'grid', placeItems: 'center', color: '#fff', fontSize: '12px' }, onclick: () => humanDraw() }, deck.length),
        unoEl(top, { w: 58 }), h('div', { style: { textAlign: 'center', fontSize: '12px' } }, h('div', { style: { width: '28px', height: '28px', borderRadius: '50%', background: UNO_C[color], margin: '0 auto 4px', border: '2px solid #fff' } }), dir > 0 ? '↻' : '↺')),
        h('div', { style: { fontSize: '13px', opacity: .9 } }, msg));
      hand.innerHTML = ''; ctl.innerHTML = '';
      if (hide) return;
      const me = P[viewer], my = turn === viewer && mine(turn) && !autoSeat(turn) && !over;
      me.h.forEach((c, idx) => hand.append(unoEl(c, { w: 46, dim: my && !ok(c), onclick: my && ok(c) ? () => { if (c.c === 'w') chooseColor(idx); else act({ p: idx }); } : null })));
      if (my) ctl.append(h('button', { class: 'nb', type: 'button', onclick: humanDraw }, drew ? 'Пропустить ход' : 'Взять карту'));
    };
    const humanDraw = () => { if (over || autoSeat(turn) || turn !== viewer || !mine(turn)) return; act(drew ? { s: 1 } : { d: 1 }); };
    if (on) { net.onLeft(() => { render(); if (autoSeat(turn) && net.isHost) step(); }); net.onRoom(() => { if (!over && autoSeat(turn) && net.isHost) step(); }); }
    ctx.score('');
    step();
  }
});

/* --- Дурак (подкидной, 36 карт) --- */
const DR = ['6', '7', '8', '9', '10', 'В', 'Д', 'К', 'Т'];
/* ===== Дурак: движок правил (2–6 игроков, подкидной/переводной, соседи/все, шулеры, ничья) ===== */
const DURAK_OPTS = [
  ['deck', 'Колода', [[24, '24'], [36, '36'], [52, '52']], 36],
  ['mode', 'Режим', [['p', 'Подкидной'], ['t', 'Переводной']], 'p'],
  ['throw', 'Кто подкидывает', [['n', 'Соседи'], ['a', 'Все']], 'n'],
  ['cheat', 'Шулеры', [[0, 'Честная игра'], [1, 'С шулерами']], 0],
  ['draw', 'Если оба вышли сразу', [[0, 'Классика'], [1, 'Ничья']], 0],
  ['fast', 'Скорость хода', [[0, 'Обычная'], [1, 'Быстрая']], 0]
];
const durakDefaults = () => { const o = {}; DURAK_OPTS.forEach(x => o[x[0]] = x[3]); return o; };
const durakClean = (o, n) => {   // приводит настройки к допустимым значениям
  const d = durakDefaults(), r = {};
  DURAK_OPTS.forEach(([k, , vals]) => { const v = o && o[k]; r[k] = vals.some(x => x[0] === v) ? v : d[k]; });
  if (r.deck === 24 && (n || 2) > 4) r.deck = 36;
  return r;
};
const durakSummary = o => { o = durakClean(o); return o.deck + ' карт · ' + (o.mode === 't' ? 'переводной' : 'подкидной') + ' · подкидывают ' + (o.throw === 'a' ? 'все' : 'соседи') + (o.cheat ? ' · с шулерами' : '') + (o.draw ? ' · ничья' : ' · классика') + (o.fast ? ' · быстрая' : ''); };
class DurakCore {
  constructor(o, N, shuf, isBot) {
    this.o = durakClean(o, N); this.N = N; this.isBot = isBot || (() => false);
    const lowR = this.o.deck === 24 ? 9 : this.o.deck === 36 ? 6 : 2, L = { 10: '10', 11: 'В', 12: 'Д', 13: 'К', 14: 'Т' };
    this.deck = shuf(['♠', '♥', '♦', '♣'].flatMap(s => { const a = []; for (let v = lowR; v <= 14; v++) a.push({ s, r: L[v] || String(v), v }); return a; }));
    this.total = this.deck.length; this.disc = 0;
    this.trump = this.deck[this.deck.length - 1];
    this.P = Array.from({ length: N }, () => ({ h: [], out: false }));
    for (let k = 0; k < 6; k++) for (let i = 0; i < N; i++) this.P[i].h.push(this.deck.shift());
    this.order = []; this.over = false; this.fool = -1; this.draw = false; this.ranks = null; this.stamp = 0; this.log = '';
    let first = 0, best = 99;
    this.P.forEach((p, i) => p.h.forEach(c => { if (c.s === this.trump.s && c.v < best) { best = c.v; first = i; } }));
    this.bout(first); this.log = 'Первым ходит ' + (best < 99 ? 'обладатель младшего козыря' : 'игрок 1');
  }
  alive(i) { return !this.P[i].out; }
  next(i) { for (let k = 1; k <= this.N; k++) { const j = (i + k) % this.N; if (!this.P[j].out) return j; } return -1; }
  bout(a) {
    this.att = a; this.def = this.next(a); this.table = []; this.taking = false; this.phase = 'atk';
    this.cap = Math.min(6, this.P[this.def].h.length); this.rebuildQueue();
  }
  rebuildQueue() {
    const q = [this.att];
    if (this.o.throw === 'a') { for (let k = 1; k < this.N; k++) { const j = (this.att + k) % this.N; if (j !== this.def && !this.P[j].out) q.push(j); } }
    else { const n = this.next(this.def); if (n >= 0 && n !== this.att && n !== this.def) q.push(n); }
    this.queue = q; this.qi = 0;
  }
  beats(a, d) { return d.s === a.s ? d.v > a.v : (d.s === this.trump.s && a.s !== this.trump.s); }
  ranksOnTable() { const s = new Set(); this.table.forEach(t => { s.add(t.a.r); if (t.d) s.add(t.d.r); }); return s; }
  limitOk() { return this.table.length < 6 && this.table.length < this.cap && (this.taking || this.P[this.def].h.length > 0); }
  canThrow(i, c) { if (!this.table.length) return i === this.att; return this.limitOk() && this.ranksOnTable().has(c.r); }
  hasThrow(i) { const h = this.P[i].h; if (!h.length) return false; if (!this.table.length) return i === this.att; if (!this.limitOk()) return false; return this.o.cheat ? true : h.some(c => this.ranksOnTable().has(c.r)); }
  actor() {
    if (this.over) return -1;
    if (this.phase === 'def') return this.def;
    while (this.qi < this.queue.length) { const i = this.queue[this.qi]; if (!this.table.length) return i; if (!this.P[i].out && this.hasThrow(i)) return i; this.qi++; }
    return -1;
  }
  canTransfer(c) {
    if (this.o.mode !== 't' || this.phase !== 'def' || this.taking || !this.table.length || this.table.some(t => t.d)) return false;
    if (c.r !== this.table[0].a.r) return false;
    const nd = this.next(this.def); return nd >= 0 && nd !== this.def && this.P[nd].h.length >= this.table.length + 1;
  }
  apply(i, x) {
    if (this.over || !x) return false;
    if (x.ch != null) return this.accuse(i, x);
    const a = this.actor();
    if (x.auto != null) { if (x.auto !== a || a < 0 || i === a) return false; return this.apply(a, this.botAct(a)); }
    if (i !== a) return false;
    const p = this.P[i], find = k => p.h.find(c => c.s + c.r === k);
    this.stamp++;
    if (this.phase === 'def') {
      if (x.take) { this.taking = true; this.phase = 'atk'; this.qi = 0; this.log = 'Берёт'; this.settle(); return true; }
      if (x.tr) { const c = find(x.tr); if (!c || !this.canTransfer(c)) return false; const nd = this.next(this.def); p.h.splice(p.h.indexOf(c), 1); this.table.push({ a: c, ao: i, tr: true }); this.att = this.def; this.def = nd; this.cap = Math.min(6, this.P[nd].h.length); this.rebuildQueue(); this.phase = 'def'; this.log = 'Перевод'; this.settle(); return true; }
      if (x.d) { const c = find(x.d), t = this.table[x.t | 0]; if (!c || !t || t.d) return false; const ok = this.beats(t.a, c); if (!ok && !this.o.cheat) return false; p.h.splice(p.h.indexOf(c), 1); t.d = c; t.do = i; if (!ok) t.db = true; this.log = ''; if (!this.table.some(t => !t.d)) { this.phase = 'atk'; this.qi = 0; } this.settle(); return true; }
      return false;
    }
    if (x.a) {
      const c = find(x.a); if (!c) return false;
      const ok = this.canThrow(i, c);
      if (!ok && !(this.o.cheat && this.table.length && this.hasThrow(i))) return false;
      p.h.splice(p.h.indexOf(c), 1); this.table.push({ a: c, ao: i, ab: !ok });
      if (!this.taking) this.phase = 'def'; this.qi = 0; this.log = ''; this.settle(); return true;
    }
    if (x.pass && this.table.length) { this.qi++; this.settle(); return true; }
    return false;
  }
  accuse(i, x) {
    if (!this.o.cheat || this.P[i].out || !this.table.length) return false;
    const t = this.table[x.ch | 0]; if (!t) return false;
    const w = x.w === 'd' ? 'd' : 'a', owner = w === 'a' ? t.ao : t.do, bad = w === 'a' ? t.ab : t.db;
    if (owner == null || owner === i || t[w + 'k']) return false;
    this.stamp++;
    if (bad) { this.log = 'Шулер пойман: забирает стол!'; this.endBout({ owner }); this.settle(); return true; }
    t[w + 'k'] = true; for (let k = 0; k < 2 && this.deck.length; k++) this.P[i].h.push(this.deck.shift());
    this.log = 'Ложное обвинение: штраф 2 карты'; return true;
  }
  settle() { for (let g = 0; g < 50; g++) { if (this.over || this.actor() >= 0) return; this.endBout(); } }
  endBout(pen) {
    const d = this.def, cards = this.table.flatMap(x => x.d ? [x.a, x.d] : [x.a]);
    const defTakes = this.taking || (pen && pen.owner === d);
    if (pen && pen.owner !== d) this.P[pen.owner].h.push(...cards);
    else if (defTakes) this.P[d].h.push(...cards);
    else { this.disc += cards.length; if (!this.log) this.log = 'Бито'; }
    this.table = [];
    for (const i of [...this.queue.filter(k => k !== d), d]) while (this.P[i].h.length < 6 && this.deck.length) this.P[i].h.push(this.deck.shift());
    const now = [];
    if (!this.deck.length) this.P.forEach((p, i) => { if (!p.out && !p.h.length) { p.out = true; now.push(i); } });
    if (now.length) this.order.push(now);
    const left = this.P.map((p, i) => i).filter(i => !this.P[i].out);
    if (left.length <= 1) { this.finish(left, now, d); return; }
    this.bout(defTakes ? this.next(d) : (this.P[d].out ? this.next(d) : d));
  }
  finish(left, now, d) {
    this.over = true; const ranks = Array(this.N).fill(0); let r = 0;
    this.order.forEach(g => { g.forEach(i => { ranks[i] = r; }); r += g.length; });
    if (left.length === 1) { this.fool = left[0]; ranks[left[0]] = r; this.draw = false; this.log = 'Дурак — игрок ' + (left[0] + 1); }
    else if (this.o.draw) { this.draw = true; this.log = 'Ничья'; }
    else { this.fool = now.includes(d) ? d : now[0]; this.draw = false; ranks[this.fool] = r; this.log = 'Дурак — игрок ' + (this.fool + 1) + ' (защитник последней карты)'; }
    this.ranks = ranks;
  }
  botAct(i) {
    const p = this.P[i], T = this.trump.s, low = a => a.slice().sort((x, y) => (x.s === T) - (y.s === T) || x.v - y.v);
    if (this.phase === 'def') {
      if (this.o.mode === 't') { const c = low(p.h.filter(c => c.s !== T && this.canTransfer(c)))[0]; if (c) return { tr: c.s + c.r }; }
      const k = this.table.findIndex(t => !t.d), t = this.table[k], c = low(p.h.filter(c => this.beats(t.a, c)))[0];
      if (!c) return { take: 1 };
      if (c.s === T && c.v >= 11 && this.deck.length > 5) return { take: 1 };
      return { d: c.s + c.r, t: k };
    }
    if (!this.table.length) { const c = low(p.h)[0]; return { a: c.s + c.r }; }
    const opts = low(p.h.filter(c => this.canThrow(i, c))).filter(c => c.s !== T || !this.deck.length || this.taking);
    if (opts.length && (opts[0].v < 12 || this.taking || !this.deck.length)) return { a: opts[0].s + opts[0].r };
    return { pass: 1 };
  }
  autoPlay() { let g = 0; for (;;) { const a = this.actor(); if (a < 0 || !this.isBot(a) || g++ > 400) return; if (!this.apply(a, this.botAct(a))) return; } }
}

game({
  id: 'durak', name: 'Дурак', like: 'подкидной и переводной', cat: 'cards', icon: '🂡', c1: '#f4a261', c2: '#9d0208', players: '2–6 игроков',
  rules: ['У каждого по 6 карт. Последняя карта колоды — козырь. Первым ходит обладатель младшего козыря.', 'Атакующий кладёт карту, защитник бьёт её старшей картой той же масти или козырем. Остальные могут подкидывать карты того же достоинства (до 6 карт).', 'Не можете или не хотите бить — «Беру». Всё отбито — «Бито».', 'Переводной: если на столе одна ещё не отбитая карта, можно подложить карту того же достоинства и перевести ход следующему.', 'Подкидывают соседи или все, колода 24/36/52, шулеры и правила ничьей настраиваются при создании комнаты. Кто остался с картами последним — дурак.'],
  run(el, ctx) {
    const net = ctx.net, on = !!net, hot = ctx.mode === 'hot';
    const BOTS = ['Бот Гриша', 'Бот Вася', 'Бот Маша', 'Бот Лена', 'Бот Коля'];
    const begin = (o, N) => {
      el.innerHTML = '';
      const nm = i => on ? net.seats[i].name + (net.isMe(net.seats[i]) ? ' (вы)' : '') : hot ? 'Игрок ' + (i + 1) : i ? BOTS[(i - 1) % 5] : (G.me && G.me.name || 'Вы');
      const isBot = i => on ? !!net.seats[i].bot : (!hot && i > 0);
      const core = new DurakCore(o, N, shuffle, isBot), T = core.trump;
      let viewer = on ? Math.max(0, net.seat) : hot ? core.att : 0, tm = 0, finished = false, sentAuto = '', pend = null, acc = false;
      const felt = h('div', { class: 'felt' }), hand = h('div', { class: 'hand' }), ctl = h('div', { class: 'bar2' }); el.append(felt, hand, ctl);
      const sortH = hh => hh.slice().sort((x, y) => (x.s === T.s) - (y.s === T.s) || x.v - y.v);
      const act = x => { pend = null; acc = false; if (on) net.send(x); else { core.apply(viewer, x); post(); } };
      const finish = () => {
        if (finished) return; finished = true; clearTimeout(tm); render();
        const f = core.fool, txt = core.draw ? 'Ничья' : nm(f) + ' — дурак!';
        if (on) ctx.ranks(core.ranks, txt);
        else if (hot) ctx.match('draw', txt);
        else ctx.match(core.draw ? 'draw' : f === 0 ? 'loss' : 'win', core.draw ? 'Ничья' : f === 0 ? 'Вы остались в дураках' : 'Победа! Дурак — ' + nm(f));
      };
      const post = () => {
        clearTimeout(tm);
        if (on) core.autoPlay();               // боты у всех считаются мгновенно и одинаково
        if (core.over) return finish();
        const a = core.actor();
        if (!on && !hot && isBot(a)) { render(); tm = setTimeout(() => { if (!ctx.alive || core.over) return; core.apply(a, core.botAct(a)); post(); }, 750); return; }
        if (hot && a >= 0 && viewer !== a) { viewer = a; render(true); passScreen(el, nm(a), () => render()); return; }
        if (on && a >= 0) {
          // за вышедшего игрока ходит программа: команду отправляет первый из оставшихся игроков, чтобы у всех всё совпало
          if (net.seats[a].left && !isBot(a) && net.isHost) { const k = core.stamp + ':' + a; if (sentAuto !== k) { sentAuto = k; net.botSend(a, core.botAct(a)); } }
          // свой ход не затягиваем: по таймеру делаем ход за себя
          if (a === net.seat) tm = setTimeout(() => { if (ctx.alive && !core.over && core.actor() === net.seat) net.send(core.botAct(net.seat)); }, (core.o.fast ? 20 : 45) * 1000);
        }
        render();
      };
      const tapCard = c => {
        if (core.over || (on && net.watching)) return;
        const a = core.actor(); if (a !== viewer || (on && net.seat !== a)) return ctx.toast('Сейчас не ваш ход');
        const key = c.s + c.r;
        if (core.phase === 'def') {
          const targets = core.table.map((t, k) => k).filter(k => !core.table[k].d && core.beats(core.table[k].a, c)), tr = core.canTransfer(c), n = targets.length + (tr ? 1 : 0);
          if (!n) { if (core.o.cheat) { ctx.toast('Шулерство! Если поймают — заберёте стол', 1600); return act({ d: key, t: core.table.findIndex(t => !t.d) }); } return ctx.toast('Этой картой нечего побить'); }
          if (n === 1) return act(tr ? { tr: key } : { d: key, t: targets[0] });
          pend = { key, targets, tr }; render(); return;
        }
        if (!core.canThrow(a, c)) { if (core.o.cheat && core.table.length) { ctx.toast('Шулерство! Если поймают — заберёте стол', 1600); return act({ a: key }); } return ctx.toast(core.table.length ? 'Подкинуть можно только карту того же достоинства, что на столе' : 'Нельзя'); }
        act({ a: key });
      };
      const tapTable = k => {
        const t = core.table[k]; if (!t || core.over) return;
        if (pend && pend.targets.includes(k)) return act({ d: pend.key, t: k });
        if (acc) { const w = t.d && t.do !== viewer ? 'd' : 'a'; return act({ ch: k, w }); }
      };
      const render = hide => {
        if (on) viewer = Math.max(0, net.seat);
        const a = core.actor(), watching = on && net.watching;
        felt.innerHTML = '';
        const opp = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '8px', justifyContent: 'center', width: '100%' } });
        for (let k = 1; k < N; k++) {
          const i = (viewer + k) % N, p = core.P[i];
          const role = p.out ? '✓ вышел' : i === core.def ? '🛡' : i === core.att ? '⚔' : core.queue.includes(i) ? '↗' : '';
          opp.append(h('div', { class: 'seat' + (a === i ? ' turn' : ''), style: { minWidth: '92px', opacity: p.out ? .55 : 1, flexDirection: 'column', gap: '2px' } },
            h('span', { class: 'av' }, isBot(i) ? '🤖' : '🙂'), h('b', { style: { fontSize: '12px' } }, nm(i)), h('small', null, p.out ? role : p.h.length + ' карт ' + role)));
          if (!p.out && p.h.length) opp.lastChild.append(h('div', { style: { display: 'flex', gap: '2px', flexWrap: 'wrap', justifyContent: 'center', maxWidth: '110px' } }, ...p.h.slice(0, 12).map(() => h('div', { class: 'pc pcb', style: { width: '10px', height: '16px', padding: 0 } }))));
        }
        felt.append(opp);
        const tb = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center', minHeight: '96px', alignItems: 'center' } });
        core.table.forEach((t, k) => tb.append(h('div', { onclick: () => tapTable(k), style: { position: 'relative', width: '60px', height: '86px', borderRadius: '8px', cursor: (acc || (pend && pend.targets.includes(k))) ? 'pointer' : 'default', outline: pend && pend.targets.includes(k) ? '3px solid #ffd166' : acc ? '2px dashed #e5383b' : 'none', outlineOffset: '2px' } }, cardEl(t.a), t.d ? h('div', { style: { position: 'absolute', left: '12px', top: '16px' } }, cardEl(t.d)) : null)));
        if (!core.table.length) tb.append(h('span', { style: { opacity: .6, fontSize: '13px' } }, 'Стол пуст'));
        const dk = core.deck.length;
        felt.append(h('div', { style: { display: 'flex', gap: '12px', alignItems: 'center', fontSize: '12px' } },
          dk ? h('div', { style: { position: 'relative', width: '62px', height: '70px' } }, h('div', { style: { position: 'absolute', left: '14px', top: '0', transform: 'rotate(90deg)', transformOrigin: 'left top', marginLeft: '40px' } }, cardEl(T)), h('div', { class: 'pc pcb', style: { position: 'absolute', left: 0, top: '4px', width: '40px', height: '58px' } })) : h('b', { style: { fontSize: '22px' } }, T.s),
          h('div', null, dk ? 'В колоде: ' + dk : 'Колода пуста', h('br'), 'Козырь: ' + T.s), tb));
        const status = core.over ? (core.draw ? 'Ничья' : nm(core.fool) + ' — дурак') : a === viewer && !watching ? (core.phase === 'def' ? 'Ваш ход: бейте карту или берите' : core.table.length ? 'Подкидывайте или нажмите «Бито»' : 'Ваш ход: ходите') : 'Ходит: ' + (a >= 0 ? nm(a) : '…');
        felt.append(h('div', { class: 'hint', style: { textAlign: 'center' } }, (core.log && !core.over ? core.log + ' · ' : '') + status));
        hand.innerHTML = ''; ctl.innerHTML = ''; if (hide || watching) return;
        sortH(core.P[viewer].h).forEach(c => hand.append(cardEl(c, { onclick: () => tapCard(c) })));
        if (core.over) return;
        if (pend) {
          if (pend.tr) ctl.append(h('button', { class: 'nb', type: 'button', onclick: () => act({ tr: pend.key }) }, 'Перевести'));
          ctl.append(h('button', { class: 'nb', type: 'button', onclick: () => { pend = null; render(); } }, 'Отмена'));
          felt.append(h('div', { class: 'hint', style: { textAlign: 'center' } }, 'Выберите карту на столе, которую побить'));
          return;
        }
        if (a === viewer && core.phase === 'def') ctl.append(h('button', { class: 'nb red', type: 'button', onclick: () => act({ take: 1 }) }, 'Беру'));
        if (a === viewer && core.phase === 'atk' && core.table.length) ctl.append(h('button', { class: 'nb', type: 'button', onclick: () => act({ pass: 1 }) }, core.taking ? 'Пусть забирает' : 'Бито'));
        if (core.o.cheat && core.table.length) ctl.append(h('button', { class: 'nb' + (acc ? ' red' : ''), type: 'button', onclick: () => { acc = !acc; render(); } }, acc ? 'Отмена: ловлю' : '🕵 Поймать шулера'));
      };
      if (on) { net.onAct((s, x) => { pend = null; core.apply(s, x); post(); }); net.onLeft(() => post()); }
      if (window.__durakDebug) { window.__durak = core; window.__durakAct = act; }
      ctx.score(''); post();
    };
    if (on) return begin(durakClean(net.room && net.room.opts, net.seats.length), net.seats.length);
    if (hot) return begin(durakDefaults(), 2);
    // против ботов: сначала настройки партии
    const cfg = Object.assign(durakDefaults(), { players: 3, cheat: 0, fast: 0 });
    const form = () => {
      el.innerHTML = '';
      const seg = (label, opts, get, set) => { const s = h('div', { class: 'seg' }); opts.forEach(([v, t]) => s.append(h('button', { class: get() === v ? 'on' : '', type: 'button', onclick: () => { set(v); form(); } }, t))); return [h('label', null, label), s]; };
      const c = h('div', { class: 'card' }, h('b', null, 'Настройки партии'),
        ...seg('Игроки (вы и боты)', [2, 3, 4, 5, 6].map(n => [n, String(n)]), () => cfg.players, v => { cfg.players = v; if (v > 4 && cfg.deck === 24) cfg.deck = 36; }),
        ...DURAK_OPTS.filter(x => x[0] !== 'cheat' && x[0] !== 'fast').map(([k, label, vals]) => seg(label, vals.filter(v => !(k === 'deck' && v[0] === 24 && cfg.players > 4)), () => cfg[k], v => { cfg[k] = v; })).flat(),
        h('button', { class: 'go', type: 'button', style: { marginTop: '14px' }, onclick: () => begin(cfg, cfg.players) }, 'Играть'));
      el.append(c);
    };
    form();
  }
});

/* --- Покер (техасский холдем на фишки) --- */
function eval7(cs) {
  const byS = {}; cs.forEach(c => (byS[c.s] = byS[c.s] || []).push(c.r));
  const sHi = rs => { const u = [...new Set(rs)].sort((a, b) => b - a); if (u.includes(14)) u.push(1); let run = 1; for (let i = 1; i < u.length; i++) { if (u[i] === u[i - 1] - 1) { if (++run >= 5) return u[i] + 4; } else run = 1; } return 0; };
  for (const s in byS) if (byS[s].length >= 5) { const v = sHi(byS[s]); if (v) return [8, v]; }
  const cnt = {}; cs.forEach(c => cnt[c.r] = (cnt[c.r] || 0) + 1);
  const g = Object.entries(cnt).map(([r, n]) => [+r, n]).sort((a, b) => b[1] - a[1] || b[0] - a[0]);
  const rs = cs.map(c => c.r).sort((a, b) => b - a), kick = (ex, n) => rs.filter(r => !ex.includes(r)).slice(0, n);
  if (g[0][1] === 4) return [7, g[0][0], ...kick([g[0][0]], 1)];
  if (g[0][1] === 3 && g[1] && g[1][1] >= 2) return [6, g[0][0], g[1][0]];
  for (const s in byS) if (byS[s].length >= 5) return [5, ...byS[s].sort((a, b) => b - a).slice(0, 5)];
  const st = sHi(rs); if (st) return [4, st];
  if (g[0][1] === 3) return [3, g[0][0], ...kick([g[0][0]], 2)];
  if (g[0][1] === 2 && g[1] && g[1][1] === 2) return [2, g[0][0], g[1][0], ...kick([g[0][0], g[1][0]], 1)];
  if (g[0][1] === 2) return [1, g[0][0], ...kick([g[0][0]], 3)];
  return [0, ...rs.slice(0, 5)];
}
const cmpH = (a, b) => { for (let i = 0; i < Math.max(a.length, b.length); i++) if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) - (b[i] || 0); return 0; };
const HAND_N = ['Старшая карта', 'Пара', 'Две пары', 'Сет', 'Стрит', 'Флеш', 'Фулл-хаус', 'Каре', 'Стрит-флеш'];
game({
  id: 'poker', name: 'Покер', like: 'техасский холдем', cat: 'cards', icon: '♠️', c1: '#2d6a4f', c2: '#081c15', players: 'вы и 3 бота', modes: ['bot'],
  rules: ['Играем на виртуальные фишки, их нельзя купить или вывести. У всех по 1000.', 'Каждому 2 карты, на стол выкладываются 5 общих. Побеждает лучшая комбинация из 5 карт.', 'Старшинство: старшая карта, пара, две пары, сет, стрит, флеш, фулл-хаус, каре, стрит-флеш.', 'Блайнды 10/20. Упрощение: в раздаче нельзя поставить больше самого маленького стека за столом.', '«Встать из-за стола» — победа, если фишек больше 1000.'],
  run(el, ctx) {
    const P = [{ n: G.me && G.me.name || 'Вы', chips: 1000 }, { n: 'Бот Лёва', chips: 1000, bot: 1, ag: .6 }, { n: 'Бот Ника', chips: 1000, bot: 1, ag: .35 }, { n: 'Бот Сэм', chips: 1000, bot: 1, ag: .8 }];
    const RN = { 11: 'В', 12: 'Д', 13: 'К', 14: 'Т' }; const card = c => ({ r: RN[c.r] || '' + c.r, s: c.s });
    let dealer = rnd(4), board = [], pot = 0, deck, cap, curBet, msg = '', showdown = false, resolveHuman = null, handNo = 0, over = false;
    const felt = h('div', { class: 'felt' }), hand = h('div', { class: 'hand' }), ctl = h('div', { class: 'bar2' }); el.append(felt, hand, ctl);
    const render = () => {
      felt.innerHTML = '';
      const seats = h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '6px', width: '100%' } });
      P.slice(1).forEach(p => seats.append(h('div', { style: { textAlign: 'center', fontSize: '12px', opacity: p.out || p.fold ? .45 : 1 } },
        h('div', { class: 'seat' + (p.turn ? ' turn' : ''), style: { justifyContent: 'center' } }, h('span', { class: 'av' }, '🤖')), h('b', null, p.n), h('div', null, '💰 ' + p.chips), p.bet ? h('div', { style: { color: '#ffd166' } }, 'ставка ' + p.bet) : null,
        h('div', { style: { display: 'flex', gap: '2px', justifyContent: 'center', marginTop: '3px', transform: 'scale(.7)', transformOrigin: 'top' } }, ...(p.hole && !p.out ? p.hole.map(c => showdown && !p.fold ? cardEl(card(c)) : cardEl(null, { back: 1 })) : [])),
        p.last ? h('div', { style: { opacity: .85 } }, p.last) : null)));
      felt.append(seats, h('div', { style: { display: 'flex', gap: '4px', minHeight: '70px' } }, ...board.map(c => cardEl(card(c)))), h('b', null, 'Банк: ' + pot), h('div', { style: { fontSize: '13px', textAlign: 'center' } }, msg));
      hand.innerHTML = ''; const me = P[0];
      if (me.hole) me.hole.forEach(c => hand.append(cardEl(card(c))));
      hand.append(h('div', { style: { alignSelf: 'center', marginLeft: '10px', fontSize: '14px' } }, h('b', null, '💰 ' + me.chips), me.bet ? h('div', { class: 'hint', style: { margin: 0 } }, 'ваша ставка ' + me.bet) : null, me.hole && board.length ? h('div', { class: 'hint', style: { margin: 0 } }, HAND_N[eval7(me.hole.concat(board))[0]]) : null));
      ctx.score(me.chips);
    };
    const act = async (i, need) => {
      const p = P[i], toCall = curBet - p.bet; p.turn = true; render();
      let a;
      if (p.bot) {
        await sleep(650); if (!ctx.alive) return 'fold';
        let s; if (!board.length) { const [x, y] = p.hole; s = x.r === y.r ? .5 + x.r / 30 : (x.r + y.r) / 34 + (x.s === y.s ? .06 : 0); }
        else { const e = eval7(p.hole.concat(board)); s = [.15 + e[1] / 100, .45, .62, .72, .82, .86, .92, .97, 1][e[0]]; }
        s += (Math.random() - .5) * .2;
        if (s > .72 && Math.random() < p.ag) a = { t: 'raise' }; else if (toCall === 0) a = { t: 'call' }; else if (s > .35 || toCall <= 20 && s > .2) a = { t: 'call' }; else a = { t: 'fold' };
      } else {
        a = await new Promise(r => { resolveHuman = r; ctl.innerHTML = ''; const rz = Math.min(cap - p.bet, curBet - p.bet + Math.max(20, Math.round(pot / 2 / 10) * 10));
          ctl.append(h('button', { class: 'nb red', onclick: () => r({ t: 'fold' }) }, 'Пас'), h('button', { class: 'nb', onclick: () => r({ t: 'call' }) }, toCall ? 'Колл ' + Math.min(toCall, p.chips) : 'Чек'));
          if (cap > curBet) ctl.append(h('button', { class: 'nb', onclick: () => r({ t: 'raise', to: p.bet + rz }) }, 'Рейз до ' + (p.bet + rz)), h('button', { class: 'nb', style: { background: 'var(--wa)', color: '#fff' }, onclick: () => r({ t: 'raise', to: cap }) }, 'Ва-банк ' + cap)); });
        ctl.innerHTML = '';
      }
      p.turn = false;
      const pay = to => { const d = Math.min(to - p.bet, p.chips); p.chips -= d; p.bet += d; pot += d; };
      if (a.t === 'fold' && toCall > 0) { p.fold = true; p.last = 'пас'; }
      else if (a.t === 'raise' && cap > curBet) { const to = Math.min(cap, a.to || curBet + Math.max(20, Math.round(pot / 20) * 10)); pay(to); curBet = Math.max(curBet, p.bet); p.last = 'рейз ' + p.bet; return 'raise'; }
      else { pay(curBet); p.last = toCall ? 'колл' : 'чек'; }
      return a.t;
    };
    const live = () => P.filter(p => !p.out && !p.fold);
    const betting = async start => {
      let need = new Set(live().filter(p => p.chips > 0).map(p => P.indexOf(p))), i = start;
      let guard = 0;
      while (need.size && live().length > 1 && guard++ < 100) {
        const p = P[i];
        if (need.has(i) && !p.fold && !p.out) {
          if (p.chips === 0) need.delete(i);
          else { const r = await act(i); if (!ctx.alive) return; need.delete(i); if (r === 'raise') live().forEach(q => { const k = P.indexOf(q); if (k !== i && q.chips > 0) need.add(k); }); }
          render();
        }
        i = (i + 1) % 4;
      }
      P.forEach(p => p.bet = 0); curBet = 0;
    };
    const nextAlive = i => { do i = (i + 1) % 4; while (P[i].out); return i; };
    const handLoop = async () => {
      while (ctx.alive && !over) {
        handNo++; showdown = false; board = []; pot = 0; msg = 'Раздача ' + handNo;
        deck = shuffle(SUITS.flatMap(s => [...Array(13)].map((_, k) => ({ s, r: k + 2 }))));
        P.forEach(p => { p.fold = false; p.bet = 0; p.last = ''; p.hole = p.out ? null : [deck.pop(), deck.pop()]; });
        cap = Math.min(...P.filter(p => !p.out).map(p => p.chips)); curBet = 0;
        dealer = nextAlive(dealer); const sb = nextAlive(dealer), bb = nextAlive(sb);
        const blind = (i, v) => { const d = Math.min(v, P[i].chips, cap); P[i].chips -= d; P[i].bet = d; pot += d; curBet = Math.max(curBet, d); };
        blind(sb, 10); blind(bb, 20); render();
        await betting(nextAlive(bb)); if (!ctx.alive) return;
        for (const n of [3, 1, 1]) { if (live().length < 2) break; board.push(...deck.splice(0, n)); msg = ['', 'Тёрн', '', 'Флоп'][n] || 'Ривер'; msg = board.length === 3 ? 'Флоп' : board.length === 4 ? 'Тёрн' : 'Ривер'; render(); await sleep(400); await betting(nextAlive(dealer)); if (!ctx.alive) return; }
        const L = live(); let win;
        if (L.length === 1) { win = L; msg = L[0].n + ' забирает банк ' + pot; }
        else { showdown = true; const ev = L.map(p => ({ p, e: eval7(p.hole.concat(board)) })); ev.sort((a, b) => cmpH(b.e, a.e)); win = ev.filter(x => cmpH(x.e, ev[0].e) === 0).map(x => x.p); msg = win.map(p => p.n).join(' и ') + ': ' + HAND_N[ev[0].e[0]] + ' · банк ' + pot; }
        const share = Math.floor(pot / win.length); win.forEach(p => p.chips += share); pot = 0;
        P.forEach(p => { if (p.chips <= 0) p.out = true; }); render();
        if (P[0].out) { over = true; ctx.match('loss', 'Фишки закончились'); return; }
        if (P.slice(1).every(p => p.out)) { over = true; ctx.match('win', 'Вы обыграли всех ботов!'); return; }
        ctl.innerHTML = ''; await new Promise(r => { ctl.append(h('button', { class: 'nb', onclick: r }, 'Следующая раздача'), h('button', { class: 'nb red', onclick: () => { over = true; r(); const c = P[0].chips; ctx.match(c > 1000 ? 'win' : c < 1000 ? 'loss' : 'draw', 'Итог: ' + c + ' фишек'); } }, 'Встать из-за стола')); });
        ctl.innerHTML = '';
      }
    };
    ctx.cleanup(() => resolveHuman && resolveHuman({ t: 'fold' }));
    handLoop();
  }
});
