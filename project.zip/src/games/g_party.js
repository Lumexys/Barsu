/* ===== Словесные и компанейские ===== */
function namesSetup(el, { min, max, def, title, note }, done) {
  let n = def; const box = h('div', { class: 'card', style: { width: 'min(100%,420px)' } });
  const draw = () => {
    box.innerHTML = ''; box.append(h('b', { style: { fontSize: '17px' } }, title), h('p', { class: 'hint' }, note));
    box.append(h('div', { class: 'row', style: { alignItems: 'center', margin: '10px 0' } }, h('button', { class: 'nb', onclick: () => { n = Math.max(min, n - 1); draw(); } }, '−'), h('b', { style: { textAlign: 'center', fontSize: '22px' } }, n + ' игроков'), h('button', { class: 'nb', onclick: () => { n = Math.min(max, n + 1); draw(); } }, '+')));
    const ins = [...Array(n)].map((_, i) => h('input', { id: 'pl' + i, placeholder: 'Игрок ' + (i + 1), maxlength: 16, style: { marginTop: '6px' } }));
    box.append(...ins, h('button', { class: 'go', onclick: () => done(ins.map((x, i) => x.value.trim() || 'Игрок ' + (i + 1))) }, 'Начать'));
  };
  draw(); el.append(box);
}

/* ===== Мафия онлайн: роли, ночь, дневной чат, голосование ===== */
function mafiaOnline(el, ctx) {
  const net = ctx.net, N = net.seats.length, me = Math.max(0, net.seat), watching = net.watching, nm = i => net.seats[i].name;
  const nM = N >= 9 ? 3 : N >= 6 ? 2 : 1;
  const roles = shuffle([...Array(nM).fill('mafia'), 'doctor', 'cop', ...Array(N - nM - 2).fill('civ')]);
  const RN = { mafia: '🔪 Мафия', doctor: '💉 Доктор', cop: '🕵️ Комиссар', civ: '🙂 Мирный' };
  const alive = Array(N).fill(true);
  let phase = 'night', day = 1, over = false, win = '', deadline = 0, tick = 0, peek = false;
  let kills = {}, heal = -1, check = -1, done = new Set(), ready = new Set(), votes = {}, chat = [], mchat = [], pub = [], checks = [], sentSkip = '';
  const ids = f => [...Array(N).keys()].filter(f);
  const live = () => ids(i => alive[i]), role = i => roles[i];
  const need = () => ids(i => alive[i] && role(i) !== 'civ');           // кто должен сходить ночью
  const box = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px', width: 'min(100%,420px)' } }); el.append(box);
  const push = t => { pub.push(t); if (pub.length > 40) pub.shift(); };
  const winner = () => { const m = live().filter(i => role(i) === 'mafia').length, o = live().length - m; return m === 0 ? 'civ' : m >= o ? 'mafia' : ''; };
  const setPhase = p => { phase = p; deadline = Date.now() + (p === 'night' ? 50000 : p === 'day' ? 80000 : 35000); sentSkip = ''; };
  const finish = w => {
    over = true; win = w; clearInterval(tick);
    push(w === 'civ' ? 'Победили мирные жители!' : 'Победила мафия!');
    const ranks = ids(() => true).map(i => ((role(i) === 'mafia') === (w === 'mafia')) ? 0 : 1);
    render(); ctx.ranks(ranks, w === 'civ' ? 'Победили мирные' : 'Победила мафия');
  };
  const endNight = () => {
    const cnt = {}; Object.values(kills).forEach(t => { if (t >= 0) cnt[t] = (cnt[t] || 0) + 1; });
    let victim = -1, best = 0; Object.keys(cnt).map(Number).sort((a, b) => a - b).forEach(t => { if (cnt[t] > best) { best = cnt[t]; victim = t; } });
    if (check >= 0) { const cp = ids(i => role(i) === 'cop')[0]; if (cp != null) checks.push({ by: cp, t: check, m: role(check) === 'mafia' }); }
    if (victim >= 0 && victim !== heal) { alive[victim] = false; push('Ночью убит ' + nm(victim) + ' (' + RN[role(victim)] + ')'); }
    else push(victim >= 0 ? 'Ночью на кого-то напали, но доктор спас жертву' : 'Ночью никто не погиб');
    kills = {}; heal = -1; check = -1; done = new Set(); ready = new Set(); votes = {}; chat = [];
    const w = winner(); if (w) return finish(w);
    setPhase('day');
  };
  const endVote = () => {
    const cnt = {}; Object.values(votes).forEach(t => { if (t >= 0) cnt[t] = (cnt[t] || 0) + 1; });
    const top = Math.max(0, ...Object.values(cnt)), who = Object.keys(cnt).filter(t => cnt[t] === top);
    if (top > 0 && who.length === 1) { const v = +who[0]; alive[v] = false; push('Город казнил ' + nm(v) + ' (' + RN[role(v)] + ')'); } else push('Голоса разделились — никто не казнён');
    const w = winner(); if (w) return finish(w);
    day++; kills = {}; done = new Set(); setPhase('night');
  };
  const pending = () => phase === 'night' ? need().filter(i => !done.has(i)) : phase === 'day' ? live().filter(i => !ready.has(i)) : phase === 'vote' ? live().filter(i => !(i in votes)) : [];
  const step = () => { if (over || pending().length) return; if (phase === 'night') endNight(); else if (phase === 'day') setPhase('vote'); else if (phase === 'vote') endVote(); };
  const apply = (s, a) => {
    if (over || s < 0 || s >= N) return;
    if (phase === 'night' && alive[s]) {
      if (a.k != null && role(s) === 'mafia' && !done.has(s)) { kills[s] = alive[a.k] && role(a.k) !== 'mafia' ? a.k | 0 : -1; done.add(s); }
      else if (a.d != null && role(s) === 'doctor' && !done.has(s)) { heal = alive[a.d] ? a.d | 0 : -1; done.add(s); }
      else if (a.i != null && role(s) === 'cop' && !done.has(s)) { check = alive[a.i] && a.i !== s ? a.i | 0 : -1; done.add(s); }
      else if (a.ns && !done.has(s) && role(s) !== 'civ') { done.add(s); }
      else if (a.mc != null && role(s) === 'mafia') mchat.push({ n: nm(s), t: String(a.mc).slice(0, 120) });
    } else if (phase === 'day' && alive[s]) {
      if (a.c != null) chat.push({ n: nm(s), t: String(a.c).slice(0, 160) });
      else if (a.rv) ready.add(s);
    } else if (phase === 'vote' && alive[s] && a.v != null && !(s in votes)) votes[s] = a.v >= 0 && alive[a.v] ? a.v | 0 : -1;
    step(); render();
  };
  const act = a => { if (!watching) net.send(a); };
  const render = () => {
    box.innerHTML = '';
    const mine = role(me), amAlive = alive[me] && !watching;
    box.append(h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' } },
      h('b', null, over ? (win === 'civ' ? '🎉 Победили мирные' : '🔪 Победила мафия') : (phase === 'night' ? '🌙 Ночь ' + day : phase === 'day' ? '☀️ День ' + day : '🗳 Голосование')),
      h('b', { id: 'mft', style: { fontFamily: 'var(--f-num)' } }, over ? '' : Math.max(0, Math.ceil((deadline - Date.now()) / 1000))),
      watching ? null : h('button', { class: 'nb', type: 'button', style: { padding: '4px 10px', touchAction: 'none' }, id: 'mfr' }, '👁 ' + (peek ? RN[mine] : 'Роль'))));
    const rb = box.querySelector('#mfr'); if (rb) { const sh = v => { peek = v; rb.textContent = '👁 ' + (v ? RN[mine] : 'Роль'); }; rb.addEventListener('pointerdown', e => { e.preventDefault(); sh(true); }); ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => rb.addEventListener(ev, () => sh(false))); }
    const grid = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px' } });
    ids(() => true).forEach(i => { const known = over || !alive[i] || (mine === 'mafia' && role(i) === 'mafia') && !watching;
      grid.append(h('span', { class: 'chip', style: { opacity: alive[i] ? 1 : .5, textDecoration: alive[i] ? 'none' : 'line-through', border: i === me ? '2px solid var(--ac)' : '' } }, (phase === 'vote' && alive[i] ? (i in votes ? '✓ ' : '') : '') + nm(i) + (known ? ' · ' + RN[role(i)] : ''))); });
    box.append(grid);
    const sel = (title, cb, filt) => { box.append(h('div', { class: 'hint', style: { margin: 0 } }, title)); const g = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px' } }); ids(i => alive[i] && filt(i)).forEach(i => g.append(h('button', { class: 'nb', type: 'button', onclick: () => cb(i) }, nm(i)))); box.append(g); };
    const chatBox = (arr, on, hint) => { const lg = h('div', { style: { maxHeight: '150px', overflowY: 'auto', background: 'var(--card)', borderRadius: '12px', padding: '6px 10px', fontSize: '13px' } }); arr.slice(-30).forEach(m => lg.append(h('div', null, h('b', null, m.n + ': '), m.t))); if (!arr.length) lg.append(h('span', { class: 'hint', style: { margin: 0 } }, hint)); box.append(lg); lg.scrollTop = lg.scrollHeight;
      if (on) { const inp = h('input', { maxlength: 160, placeholder: 'Сообщение…', style: { flex: 1, minWidth: 0 } }), snd = () => { const t = inp.value.trim(); if (t) { inp.value = ''; act(on(t)); } }; inp.addEventListener('keydown', e => e.key === 'Enter' && snd()); box.append(h('div', { style: { display: 'flex', gap: '8px' } }, inp, h('button', { class: 'go', type: 'button', style: { width: '56px', padding: 0 }, onclick: snd }, '➤'))); } };
    if (!over) {
      if (phase === 'night') {
        if (!amAlive) box.append(h('p', { class: 'hint' }, 'Вы выбыли и наблюдаете за игрой.'));
        else if (mine === 'civ') box.append(h('p', { class: 'hint' }, 'Город спит. Ждите утра…'));
        else if (done.has(me)) box.append(h('p', { class: 'hint' }, 'Ход сделан. Ждём остальных…'));
        else if (mine === 'mafia') { sel('Выберите жертву', i => act({ k: i }), i => role(i) !== 'mafia'); box.append(h('button', { class: 'nb', type: 'button', onclick: () => act({ ns: 1 }) }, 'Пропустить')); }
        else if (mine === 'doctor') { sel('Кого лечим этой ночью?', i => act({ d: i }), () => true); box.append(h('button', { class: 'nb', type: 'button', onclick: () => act({ ns: 1 }) }, 'Пропустить')); }
        else if (mine === 'cop') { sel('Кого проверяем?', i => act({ i }), i => i !== me); box.append(h('button', { class: 'nb', type: 'button', onclick: () => act({ ns: 1 }) }, 'Пропустить')); }
        if (amAlive && mine === 'mafia') chatBox(mchat, t => ({ mc: t }), 'Тайный чат мафии');
      } else if (phase === 'day') {
        chatBox(chat, amAlive ? t => ({ c: t }) : null, 'Обсуждайте, кто мафия');
        if (amAlive) box.append(ready.has(me) ? h('p', { class: 'hint' }, 'Вы готовы к голосованию (' + ready.size + '/' + live().length + ')') : h('button', { class: 'go', type: 'button', onclick: () => act({ rv: 1 }) }, 'К голосованию'));
      } else {
        if (amAlive && !(me in votes)) { sel('Кого казнить?', i => act({ v: i }), i => i !== me); box.append(h('button', { class: 'nb', type: 'button', onclick: () => act({ v: -1 }) }, 'Воздержаться')); }
        else box.append(h('p', { class: 'hint' }, 'Проголосовало: ' + Object.keys(votes).length + ' из ' + live().length));
      }
    }
    const mc = checks.filter(c => c.by === me); if (mc.length && !watching) box.append(h('div', { class: 'hint', style: { margin: 0 } }, 'Проверки: ' + mc.map(c => nm(c.t) + (c.m ? ' — МАФИЯ' : ' — мирный')).join('; ')));
    const lg = h('div', { class: 'hint', style: { margin: 0 } }); pub.slice(-6).forEach(t => lg.append(h('div', null, '• ' + t))); box.append(lg);
  };
  net.onAct(apply); net.onLeft(() => { });
  ctx.score(''); setPhase('night'); push('Игра началась. Мафия: ' + nM + ' из ' + N + '.'); render();
  tick = setInterval(() => {
    if (!ctx.alive) return clearInterval(tick); if (over) return;
    const t = document.getElementById('mft'); if (t) t.textContent = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    const late = Date.now() > deadline, pend = pending(), key = phase + day + ':' + pend.join(',');
    const skipOf = i => phase === 'night' ? { ns: 1 } : phase === 'day' ? { rv: 1 } : { v: -1 };
    if (late && pend.includes(me) && !watching && sentSkip !== 'me' + key) { sentSkip = 'me' + key; net.send(skipOf(me)); }
    if (net.isHost && sentSkip.indexOf('h' + key) < 0) { const gone = pend.filter(i => net.seats[i].left || net.seats[i].bot); if (gone.length) { sentSkip += 'h' + key; gone.forEach(i => net.botSend(i, skipOf(i))); } }
  }, 1000);
}

game({
  id: 'mafia', name: 'Мафия', like: 'ведущий в телефоне', cat: 'party', icon: '🕵️', c1: '#6c757d', c2: '#000', players: '6–12 игроков', modes: ['live'],
  rules: ['Телефон — у ведущего, остальные сидят рядом.', 'Сначала телефон передают по кругу: каждый тайно смотрит свою роль.', 'Ночью мафия выбирает жертву, доктор лечит, комиссар проверяет. Ведущий отмечает выбор в приложении.', 'Днём все обсуждают и голосуют, кого исключить.', 'Мирные побеждают, если мафии не осталось. Мафия — если её не меньше, чем мирных.', 'В онлайн-версии нужен чат с модерацией, поэтому основной режим — живая игра.'],
  run(el, ctx) {
    if (ctx.net) return mafiaOnline(el, ctx);
    ctx.score('');
    namesSetup(el, { min: 6, max: 12, def: 7, title: 'Кто играет?', note: 'Ведущий не играет — он держит телефон.' }, names => {
      const n = names.length, mc = n >= 11 ? 4 : n >= 8 ? 3 : 2;
      const roles = shuffle([...Array(mc).fill('Мафия'), 'Комиссар', 'Доктор', ...Array(n - mc - 2).fill('Мирный')]);
      const P = names.map((nm, i) => ({ nm, r: roles[i], alive: true }));
      const RI = { 'Мафия': '🔫', 'Комиссар': '🕵️', 'Доктор': '💊', 'Мирный': '🙂' };
      let day = 0;
      const screen = (...k) => { el.innerHTML = ''; el.append(h('div', { class: 'card', style: { width: 'min(100%,420px)', textAlign: 'center' } }, ...k)); };
      const deal = i => {
        if (i >= n) return night();
        screen(h('div', { style: { fontSize: '40px' } }, '🤫'), h('b', { style: { fontSize: '18px' } }, 'Передайте телефон: ' + P[i].nm), h('button', { class: 'go', onclick: () => screen(h('div', { style: { fontSize: '60px' } }, RI[P[i].r]), h('b', { style: { fontSize: '24px' } }, P[i].r), h('p', { class: 'hint' }, P[i].r === 'Мафия' ? 'Ваши сообщники: ' + P.filter((p, j) => p.r === 'Мафия' && j !== i).map(p => p.nm).join(', ') : P[i].r === 'Комиссар' ? 'Каждую ночь проверяете одного игрока' : P[i].r === 'Доктор' ? 'Каждую ночь спасаете одного игрока' : 'Найдите мафию днём'), h('button', { class: 'go', onclick: () => deal(i + 1) }, 'Запомнил, скрыть')) }, 'Показать мою роль'));
      };
      const pickOne = (title, hint, list, cb) => { screen(h('b', { style: { fontSize: '18px' } }, title), h('p', { class: 'hint' }, hint), h('div', { style: { display: 'grid', gap: '6px', marginTop: '8px' } }, ...list.map(p => h('button', { class: 'nb', onclick: () => cb(p) }, p.nm))), cb.skip ? h('button', { class: 'go sec', onclick: () => cb(null) }, 'Пропустить') : ''); };
      const alive = () => P.filter(p => p.alive);
      const winCheck = () => { const m = alive().filter(p => p.r === 'Мафия').length, c = alive().length - m; if (!m) return 'Мирные жители победили! 🎉'; if (m >= c) return 'Победила мафия 🔫'; return null; };
      const finish = t => { screen(h('div', { style: { fontSize: '50px' } }, '🏁'), h('b', { style: { fontSize: '20px' } }, t), h('p', { class: 'hint', style: { textAlign: 'left' } }, P.map(p => `${RI[p.r]} ${p.nm} — ${p.r}${p.alive ? '' : ' (выбыл)'}`).join('\n')), h('button', { class: 'go', onclick: () => ctx.match('draw', t) }, 'Завершить')); el.querySelector('.hint').style.whiteSpace = 'pre-line'; };
      const night = () => {
        day++; let victim, saved;
        screen(h('div', { style: { fontSize: '50px' } }, '🌙'), h('b', { style: { fontSize: '20px' } }, 'Ночь ' + day), h('p', { class: 'hint' }, 'Ведущий читает вслух: «Город засыпает. Мафия просыпается и молча выбирает жертву».'), h('button', { class: 'go', onclick: () => {
          pickOne('Кого выбрала мафия?', 'Покажите пальцем, ведущий нажимает', alive(), v => { victim = v;
            const doc = alive().find(p => p.r === 'Доктор'), com = alive().find(p => p.r === 'Комиссар');
            const afterDoc = () => { if (com) { pickOne('Комиссар просыпается', 'Кого проверяет комиссар?', alive().filter(p => p !== com), c => { screen(h('b', { style: { fontSize: '20px' } }, c.nm + (c.r === 'Мафия' ? ' — мафия 👎' : ' — не мафия 👍')), h('p', { class: 'hint' }, 'Покажите комиссару жестом. Он засыпает.'), h('button', { class: 'go', onclick: morning } , 'Утро')); }); } else morning(); };
            if (doc) pickOne('Доктор просыпается', 'Кого лечит доктор?', alive(), d => { saved = d; afterDoc(); }); else afterDoc();
          });
        } }, 'Начать ночь'));
        const morning = () => {
          let t; if (victim && victim !== saved) { victim.alive = false; t = 'Этой ночью выбыл ' + victim.nm; } else t = 'Этой ночью никто не погиб — доктор успел';
          const w = winCheck(); if (w) return finish(t + '. ' + w);
          let left = 90, tid;
          const tm = h('div', { style: { fontSize: '44px', fontWeight: 800, fontFamily: 'var(--f-num)' } }, '1:30');
          screen(h('div', { style: { fontSize: '50px' } }, '☀️'), h('b', { style: { fontSize: '19px' } }, t), h('p', { class: 'hint' }, 'Обсуждение. В живых: ' + alive().map(p => p.nm).join(', ')), tm, h('button', { class: 'go', onclick: () => { clearInterval(tid); vote(); } }, 'К голосованию'));
          tid = ctx.every(() => { left--; tm.textContent = Math.floor(Math.max(0, left) / 60) + ':' + String(Math.max(0, left) % 60).padStart(2, '0'); if (left <= 0) { clearInterval(tid); tm.style.color = 'var(--rd)'; } }, 1000);
        };
      };
      const vote = () => { const f = p => { if (p) p.alive = false; const w = winCheck(); if (w) return finish((p ? p.nm + ' исключён. ' : '') + w); screen(h('b', { style: { fontSize: '19px' } }, p ? p.nm + ' покидает игру' : 'Город никого не исключил'), h('button', { class: 'go', onclick: night }, 'Наступает ночь')); }; f.skip = true; pickOne('Голосование', 'Кого исключает город? (по большинству голосов)', alive(), f); };
      deal(0);
    });
  }
});

const CROC = ['Зачётка', 'Стипендия', 'Студенческий билет', 'Шпаргалка', 'Общежитие', 'Библиотека', 'Будильник', 'Столовая', 'Костёр', 'Палатка', 'Компас', 'Самокат', 'Пылесос', 'Жираф', 'Кенгуру', 'Пингвин', 'Повар', 'Пожарный', 'Балерина', 'Космонавт', 'Зубная щётка', 'Холодильник', 'Микроволновка', 'Зонтик', 'Снеговик', 'Гитара', 'Барабан', 'Скрипка', 'Удочка', 'Сноуборд', 'Лифт', 'Светофор', 'Автобус', 'Драники', 'Аист', 'Зубр', 'Шахматы', 'Шашлык', 'Ёлка', 'Подарок', 'Фейерверк', 'Утюг', 'Стиральная машина', 'Кот в сапогах', 'Колобок', 'Русалка', 'Робот', 'Динозавр', 'Привидение', 'Фокусник', 'Ракета', 'Маяк', 'Радуга', 'Кактус', 'Улитка', 'Осьминог', 'Вертолёт', 'Корона', 'Очки', 'Наушники', 'Микрофон', 'Пицца', 'Мороженое', 'Арбуз', 'Ананас', 'Велосипед', 'Парашют', 'Замок', 'Мост', 'Глобус', 'Микроскоп', 'Телескоп', 'Лампочка', 'Ножницы', 'Батарейка', 'Песочные часы', 'Якорь', 'Паук', 'Бабочка', 'Сова', 'Ёжик', 'Черепаха', 'Дракон', 'Единорог', 'Вулкан', 'Пирамида', 'Эйфелева башня', 'Снежинка', 'Молния', 'Луна', 'Солнце', 'Облако', 'Дождь', 'Рюкзак', 'Карандаш', 'Доска', 'Звонок', 'Диплом', 'Кофе'];
/* ===== Крокодил онлайн: рисует один, остальные угадывают текстом ===== */
function crocOnline(el, ctx) {
  const net = ctx.net, N = net.seats.length, S = 340, me = Math.max(0, net.seat), watching = net.watching;
  const COL = ['#111111', '#e63946', '#f4a100', '#2a9d5c', '#1f6fd1', '#7b2cbf', '#8d5524', '#ff8fab', '#ffffff'];
  const norm = t => String(t).toLowerCase().replace(/ё/g, 'е').replace(/[^a-zа-я0-9]/g, '');
  const nm = i => net.seats[i].name;
  const turns = N > 5 ? 1 : 2, order = [...Array(turns)].flatMap(() => net.seats.map((_, i) => i));
  const words = shuffle(CROC.slice());
  const sc = Array(N).fill(0), chat = [];
  let rd = -1, phase = 'start', wi = 0, strokes = [], guessedBy = -1, finished = false, deadline = 0, tick = 0;
  const drawer = () => order[rd];
  const word = () => words[(rd * 3 + wi) % words.length];
  const box = h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', width: '100%' } });
  el.append(box);
  const head = h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: 'min(100%,400px)', gap: '8px' } });
  const [c, x] = canvas(box, S, S); c.style.background = '#fff'; c.style.maxHeight = 'calc(100dvh - 400px)';
  const tools = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', justifyContent: 'center', width: 'min(100%,400px)' } });
  const log = h('div', { style: { width: 'min(100%,400px)', maxHeight: '120px', overflowY: 'auto', fontSize: '13px', background: 'var(--card)', borderRadius: '12px', padding: '6px 10px', textAlign: 'left' } });
  const inp = h('input', { maxlength: 40, placeholder: 'Ваша догадка…', autocomplete: 'off', style: { flex: 1, minWidth: 0 } });
  const gbtn = h('button', { class: 'go', type: 'button', style: { width: '56px', padding: 0 } }, '➤');
  const row = h('div', { style: { display: 'flex', gap: '8px', width: 'min(100%,400px)' } }, inp, gbtn);
  const board = h('div', { class: 'hint', style: { margin: 0, textAlign: 'center' } });
  box.prepend(head); box.append(tools, log, row, board);
  const seg = (s) => { x.strokeStyle = COL[s.c]; x.lineWidth = s.w; x.lineCap = x.lineJoin = 'round'; };
  const redraw = () => { x.fillStyle = '#fff'; x.fillRect(0, 0, S, S); strokes.forEach(s => { seg(s); x.beginPath(); for (let i = 0; i < s.p.length; i += 2) i ? x.lineTo(s.p[i], s.p[i + 1]) : x.moveTo(s.p[i], s.p[i + 1]); if (s.p.length === 2) x.lineTo(s.p[0] + .1, s.p[1]); x.stroke(); }); };
  const line = (s, a, b, c2, d) => { seg(s); x.beginPath(); x.moveTo(a, b); x.lineTo(c2, d); x.stroke(); };
  const render = () => {
    const d = rd >= 0 ? drawer() : -1, mine = d === me && !watching;
    head.innerHTML = '';
    if (phase === 'draw' || phase === 'between') {
      const hint = mine ? word() : phase === 'between' ? word() : [...word()].map((ch, k) => ch === ' ' ? '  ' : (k === 0 && deadline - Date.now() < 40000) ? ch : '_').join('');
      head.append(h('span', { style: { fontWeight: 700, fontSize: '14px' } }, '🎨 ' + nm(d) + ' · ' + (rd + 1) + '/' + order.length), h('b', { style: { letterSpacing: '3px', fontSize: mine || phase === 'between' ? '18px' : '15px' } }, hint),
        h('b', { id: 'crt', style: { fontFamily: 'var(--f-num)', minWidth: '40px', textAlign: 'right' } }, phase === 'draw' ? Math.max(0, Math.ceil((deadline - Date.now()) / 1000)) : ''));
    }
    tools.innerHTML = '';
    if (phase === 'draw' && mine) {
      COL.forEach((cc, k) => tools.append(h('button', { 'aria-label': 'Цвет', onclick: () => { col = k; render(); }, style: { width: '28px', height: '28px', borderRadius: '50%', background: cc, boxShadow: col === k ? '0 0 0 3px var(--bg),0 0 0 5px var(--ac)' : 'inset 0 0 0 2px rgba(0,0,0,.15)' } })));
      [[3, '·'], [6, '•'], [12, '●']].forEach(([s, t]) => tools.append(h('button', { class: 'nb', style: { padding: '4px 10px', background: size === s ? 'var(--ac)' : '', color: size === s ? '#fff' : '' }, onclick: () => { size = s; render(); } }, t)));
      tools.append(h('button', { class: 'nb', style: { padding: '4px 10px' }, onclick: () => net.send({ u: 1 }) }, '↶'), h('button', { class: 'nb', style: { padding: '4px 10px' }, onclick: () => net.send({ cl: 1 }) }, '🗑'), h('button', { class: 'nb', style: { padding: '4px 10px' }, onclick: () => net.send({ sw: 1 }) }, '🔄 Другое слово'));
    }
    row.style.display = phase === 'draw' && !mine && !watching ? 'flex' : 'none';
    log.innerHTML = ''; chat.slice(-30).forEach(m => log.append(h('div', { style: m.ok ? { color: 'var(--ok)', fontWeight: 700 } : {} }, m.ok ? '🎉 ' + m.n + ' угадал(а): ' + m.t : h('span', null, h('b', null, m.n + ': '), m.t)))); log.scrollTop = log.scrollHeight;
    board.textContent = net.seats.map((s, i) => nm(i) + ': ' + sc[i]).join(' · ');
    if (phase === 'start') head.append(h('span', null, 'Игра начинается…'));
  };
  let col = 0, size = 6, cur = null, buf = [], flushT = 0, last = null;
  const flush = () => { flushT = 0; if (buf.length) { net.send({ m: buf.splice(0, 40) }); if (buf.length) flushT = setTimeout(flush, 90); } };
  const P = e => { const q = c.pos(e); return [Math.max(0, Math.min(S, Math.round(q.x))), Math.max(0, Math.min(S, Math.round(q.y)))]; };
  ctx.on(c, 'pointerdown', e => { if (phase !== 'draw' || drawer() !== me || watching) return; c.setPointerCapture(e.pointerId); const [px, py] = P(e); cur = { c: col, w: col === 8 ? size * 4 : size, p: [px, py] }; last = [px, py]; net.send({ b: [col, cur.w, px, py] }); seg(cur); x.beginPath(); x.moveTo(px, py); x.lineTo(px + .1, py); x.stroke(); });
  ctx.on(c, 'pointermove', e => { if (!cur) return; const [px, py] = P(e); if (Math.hypot(px - last[0], py - last[1]) < 2) return; line(cur, last[0], last[1], px, py); last = [px, py]; buf.push(px, py); if (!flushT) flushT = setTimeout(flush, 90); });
  const up = () => { if (!cur) return; cur = null; clearTimeout(flushT); flush(); }; ctx.on(c, 'pointerup', up); ctx.on(c, 'pointercancel', up);
  const send = () => { const t = inp.value.trim(); if (!t || phase !== 'draw') return; inp.value = ''; net.send({ g: t.slice(0, 40) }); };
  gbtn.onclick = send; inp.addEventListener('keydown', e => e.key === 'Enter' && send());
  const startRound = () => {
    rd++; if (rd >= order.length) return end();
    wi = 0; strokes = []; guessedBy = -1; chat.length = 0; phase = 'draw'; deadline = Date.now() + 80000; redraw(); render();
    clearInterval(tick); tick = setInterval(() => {
      if (!ctx.alive) return clearInterval(tick);
      const t = document.getElementById('crt'); if (t && phase === 'draw') t.textContent = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      if (phase === 'draw' && Date.now() > deadline + 1500 - (drawer() === me ? 1500 : 0)) {   // время вышло: раунд завершает рисующий, остальные подстраховывают позже
        const rr = rd; if (drawer() === me) net.send({ end: rr }); else if (net.isHost && Date.now() > deadline + 6000) net.botSend(drawer(), { end: rr });
      }
      if (phase === 'draw' && net.seats[drawer()].left && net.isHost) net.botSend(drawer(), { end: rd });
    }, 700);
  };
  const end = () => {
    if (finished) return; finished = true; phase = 'over'; clearInterval(tick); render();
    const best = Math.max(...sc), ranks = sc.map(v => sc.filter(w => w > v).length);
    head.innerHTML = ''; head.append(h('b', null, '🏆 ' + net.seats.filter((_, i) => sc[i] === best).map(s => s.name).join(', ')));
    ctx.ranks(ranks, 'Игра окончена');
  };
  const roundEnd = who => {
    if (phase !== 'draw') return; phase = 'between'; guessedBy = who;
    if (who >= 0) { sc[who] += 2; sc[drawer()] += 1; }
    chat.push({ ok: who < 0 ? 0 : 1, n: who < 0 ? '' : nm(who), t: word() }); if (who < 0) chat[chat.length - 1] = { n: 'Слово было', t: word() };
    render(); const rr = rd; setTimeout(() => { if (ctx.alive && drawer() === me || (net.isHost && ctx.alive)) net.send({ nx: rr }); }, 3500);
  };
  net.onAct((s, a) => {
    if (finished) return;
    if (phase === 'start' && a.go) { startRound(); return; }
    if (a.nx != null) { if (phase === 'between' && a.nx === rd) startRound(); return; }
    if (phase !== 'draw') return;
    const d = drawer();
    if (a.end != null) { if (a.end === rd) roundEnd(-1); return; }
    if (a.g != null) {
      if (s === d || typeof a.g !== 'string') return;
      if (norm(a.g) === norm(word())) { roundEnd(s); return; }
      chat.push({ n: nm(s), t: String(a.g).slice(0, 40) }); render(); return;
    }
    if (s !== d) return;
    if (a.sw) { wi++; strokes = []; redraw(); chat.length = 0; render(); return; }
    if (a.u) { strokes.pop(); redraw(); return; }
    if (a.cl) { strokes = []; redraw(); return; }
    if (a.b) { strokes.push({ c: a.b[0] | 0, w: a.b[1] | 0, p: [a.b[2] | 0, a.b[3] | 0] }); return; }
    if (a.m && strokes.length) { const st = strokes[strokes.length - 1]; for (let i = 0; i + 1 < a.m.length; i += 2) { const px = a.m[i] | 0, py = a.m[i + 1] | 0; if (s !== me) line(st, st.p[st.p.length - 2], st.p[st.p.length - 1], px, py); st.p.push(px, py); } }
  });
  // начало: первый игрок комнаты запускает партию
  if (net.isHost) net.send({ go: 1 });
  ctx.score(''); render();
}

game({
  id: 'crocodile', name: 'Крокодил', like: 'один рисует, все угадывают', cat: 'party', icon: '🐊', c1: '#80b918', c2: '#2b9348', players: '3–8 игроков', modes: ['hot'],
  rules: ['Игроки по очереди рисуют. Художник выбирает одно из трёх слов и рисует его пальцем.', 'Буквы и цифры писать нельзя! Остальные смотрят на экран и угадывают вслух.', 'Кто угадал первым — нажмите его имя: ему 2 очка, художнику 1. На рисунок 80 секунд.', 'Слово можно подсмотреть, удерживая кнопку «👁 Слово».', 'Каждый рисует по два раза (если игроков больше пяти — по одному). Побеждает тот, у кого больше очков.', 'В онлайн-версии все видят рисунок на своих телефонах в реальном времени и пишут догадки в чат — приложение само проверяет ответ.'],
  run(el, ctx) {
    ctx.score('');
    if (ctx.net) return crocOnline(el, ctx);
    namesSetup(el, { min: 3, max: 8, def: 4, title: 'Кто играет?', note: 'Рисуют по очереди на этом телефоне, остальные смотрят на экран.' }, names => {
      const sc = names.map(() => 0), turns = names.length > 5 ? 1 : 2, order = [...Array(turns)].flatMap(() => names.map((_, i) => i));
      const words = shuffle(CROC.slice()); let wi = 0, ti = 0;
      const scr = (...k) => { el.innerHTML = ''; el.append(h('div', { class: 'card', style: { width: 'min(100%,420px)', textAlign: 'center' } }, ...k)); };
      const table = () => h('p', { class: 'hint' }, names.map((n, i) => n + ': ' + sc[i]).sort((a, b) => +b.split(': ')[1] - +a.split(': ')[1]).join(' · '));
      const next = () => {
        if (ti >= order.length) { const best = Math.max(...sc); scr(h('div', { style: { fontSize: '48px' } }, '🏆'), h('b', { style: { fontSize: '20px' } }, names.filter((_, i) => sc[i] === best).join(', ') + ' — лучший художник и отгадчик'), table(), h('button', { class: 'go', onclick: () => ctx.match('draw', 'Игра окончена') }, 'Завершить')); return; }
        const d = order[ti];
        scr(h('small', { class: 'hint' }, 'Ход ' + (ti + 1) + ' из ' + order.length), h('div', { style: { fontSize: '44px' } }, '🎨'), h('b', { style: { fontSize: '19px', display: 'block' } }, 'Рисует: ' + names[d]), h('p', { class: 'hint' }, 'Остальные, не подглядывайте, пока ' + names[d] + ' выбирает слово'), table(),
          h('button', { class: 'go', onclick: () => { const opts = [words[wi++ % words.length], words[wi++ % words.length], words[wi++ % words.length]]; scr(h('b', { style: { fontSize: '18px' } }, names[d] + ', выберите слово'), h('div', { style: { display: 'grid', gap: '8px', marginTop: '12px' } }, ...opts.map(w => h('button', { class: 'nb', style: { padding: '14px', fontSize: '17px' }, onclick: () => draw(d, w) }, w)))); } }, 'Я ' + names[d] + ', выбрать слово'));
      };
      const draw = (d, word) => {
        el.innerHTML = '';
        const S = 340, [c, x] = canvas(el, S, S); c.style.background = '#fff'; c.style.maxHeight = 'calc(100dvh - 330px)';
        const COL = ['#111111', '#e63946', '#f4a100', '#2a9d5c', '#1f6fd1', '#7b2cbf', '#8d5524', '#ff8fab'];
        let col = COL[0], size = 6, erase = false, strokes = [], cur = null, left = 80, done = false;
        const redraw = () => { x.fillStyle = '#fff'; x.fillRect(0, 0, S, S); strokes.forEach(s => { x.strokeStyle = s.c; x.lineWidth = s.w; x.lineCap = x.lineJoin = 'round'; x.beginPath(); s.p.forEach((q, i) => i ? x.lineTo(q.x, q.y) : x.moveTo(q.x, q.y)); if (s.p.length === 1) x.lineTo(s.p[0].x + .1, s.p[0].y); x.stroke(); }); };
        redraw();
        ctx.on(c, 'pointerdown', e => { if (done) return; c.setPointerCapture(e.pointerId); cur = { c: erase ? '#fff' : col, w: erase ? size * 4 : size, p: [c.pos(e)] }; strokes.push(cur); redraw(); });
        ctx.on(c, 'pointermove', e => { if (!cur) return; const q = c.pos(e), l = cur.p[cur.p.length - 1]; if (Math.hypot(q.x - l.x, q.y - l.y) < 1.5) return; cur.p.push(q); x.strokeStyle = cur.c; x.lineWidth = cur.w; x.lineCap = 'round'; x.beginPath(); x.moveTo(l.x, l.y); x.lineTo(q.x, q.y); x.stroke(); });
        const up = () => { cur = null; }; ctx.on(c, 'pointerup', up); ctx.on(c, 'pointercancel', up);
        const tools = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', justifyContent: 'center', width: 'min(100%,400px)' } });
        const drawTools = () => {
          tools.innerHTML = '';
          COL.forEach(cc => tools.append(h('button', { 'aria-label': 'Цвет', onclick: () => { col = cc; erase = false; drawTools(); }, style: { width: '30px', height: '30px', borderRadius: '50%', background: cc, boxShadow: !erase && col === cc ? '0 0 0 3px var(--bg),0 0 0 5px var(--ac)' : 'inset 0 0 0 2px rgba(0,0,0,.1)' } })));
          [[3, '·'], [6, '•'], [12, '●']].forEach(([s, t]) => tools.append(h('button', { class: 'nb', style: { padding: '4px 10px', background: size === s ? 'var(--ac)' : '', color: size === s ? '#fff' : '' }, onclick: () => { size = s; drawTools(); } }, t)));
          tools.append(h('button', { class: 'nb', style: { padding: '4px 10px', background: erase ? 'var(--ac)' : '', color: erase ? '#fff' : '' }, onclick: () => { erase = !erase; drawTools(); } }, '🧽'), h('button', { class: 'nb', style: { padding: '4px 10px' }, onclick: () => { strokes.pop(); redraw(); } }, '↶'), h('button', { class: 'nb red', style: { padding: '4px 10px' }, onclick: () => { strokes = []; redraw(); } }, '🗑'));
        };
        drawTools();
        const peek = h('button', { class: 'nb', style: { touchAction: 'none', flex: 'none' } }, '👁 Слово');
        const show = on => { peek.textContent = on ? word : '👁 Слово'; }; peek.addEventListener('pointerdown', e => { e.preventDefault(); show(true); }); ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => peek.addEventListener(ev, () => show(false)));
        const tm = h('b', { style: { fontFamily: 'var(--f-num)', fontSize: '20px', minWidth: '44px', textAlign: 'center' } }, '80');
        const hint = h('span', { class: 'hint', style: { margin: 0, letterSpacing: '3px', fontWeight: 700 } }, [...word].map(ch => ch === ' ' ? '  ' : '_').join(''));
        el.prepend(h('div', { style: { display: 'flex', alignItems: 'center', gap: '10px', width: 'min(100%,400px)', justifyContent: 'space-between' } }, h('span', { style: { fontWeight: 700, fontSize: '14px' } }, '🎨 ' + names[d]), hint, tm, peek));
        const who = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', justifyContent: 'center', width: 'min(100%,400px)' } }, h('span', { class: 'hint', style: { width: '100%', textAlign: 'center', margin: 0 } }, 'Кто угадал первым?'));
        names.forEach((n, i) => { if (i !== d) who.append(h('button', { class: 'nb', style: { flex: 'none', background: 'var(--ok)', color: '#fff' }, onclick: () => end(i) }, n)); });
        who.append(h('button', { class: 'nb red', style: { flex: 'none' }, onclick: () => end(-1) }, 'Никто'));
        el.append(tools, who);
        const tid = ctx.every(() => { left--; tm.textContent = Math.max(0, left); tm.style.color = left <= 10 ? 'var(--rd)' : ''; if (left === 40) hint.textContent = [...word].map((ch, k) => k === 0 || ch === ' ' ? ch : '_').join(''); if (left <= 0) end(-1); }, 1000);
        const end = g => {
          if (done) return; done = true; clearInterval(tid);
          if (g >= 0) { sc[g] += 2; sc[d] += 1; }
          const img = h('img', { src: c.toDataURL('image/png'), alt: 'Рисунок', style: { width: '160px', borderRadius: '12px', boxShadow: 'var(--sh)', background: '#fff' } });
          scr(img, h('div', { style: { fontSize: '26px', fontWeight: 800, margin: '10px 0 4px' } }, word), h('p', { class: 'hint' }, g >= 0 ? names[g] + ' угадал(а): +2, ' + names[d] + ' +1' : 'Никто не угадал'), table(), h('button', { class: 'go', onclick: () => { ti++; next(); } }, 'Дальше'));
        };
      };
      next();
    });
  }
});

game({
  id: 'hangman', name: 'Виселица', like: 'угадай слово по буквам', cat: 'party', icon: '🪢', c1: '#ffd6a5', c2: '#e76f51',
  rules: ['Угадайте слово, называя буквы.', 'Каждая ошибка дорисовывает человечка. 7 ошибок — проигрыш.', 'С ботом слово загадывает приложение. На одном телефоне — первый игрок вводит слово, второй угадывает.'],
  run(el, ctx) {
    const bank = CW_WORDS.map(([w, c]) => [w.replace('ё', 'е'), c]);
    const play = (word, hint) => {
      el.innerHTML = ''; const got = new Set(), bad = new Set(); let over = false;
      const [c, x] = canvas(el, 220, 170); c.style.boxShadow = 'none'; c.style.background = 'var(--card)';
      const wd = h('div', { style: { fontSize: '30px', letterSpacing: '6px', fontWeight: 800, fontFamily: 'var(--f-num)', textTransform: 'uppercase', textAlign: 'center', overflowWrap: 'anywhere' } });
      const inf = info(el); el.append(wd); const kw = h('div', { style: { width: '100%', display: 'flex', justifyContent: 'center' } }); el.append(kw);
      const keys = kbRU(kw, k => guess(k), '—');
      const paint = () => {
        x.clearRect(0, 0, 220, 170); x.strokeStyle = cssv('--tx'); x.lineWidth = 4; x.lineCap = 'round';
        const n = bad.size, L = (a, b, c2, d) => { x.beginPath(); x.moveTo(a, b); x.lineTo(c2, d); x.stroke(); };
        L(20, 160, 120, 160); L(50, 160, 50, 15); L(50, 15, 140, 15); L(140, 15, 140, 35);
        if (n > 0) { x.beginPath(); x.arc(140, 50, 15, 0, 7); x.stroke(); } if (n > 1) L(140, 65, 140, 110); if (n > 2) L(140, 75, 118, 95); if (n > 3) L(140, 75, 162, 95); if (n > 4) L(140, 110, 122, 140); if (n > 5) L(140, 110, 158, 140); if (n > 6) { x.strokeStyle = cssv('--rd'); L(132, 45, 138, 51); L(138, 45, 132, 51); L(142, 45, 148, 51); L(148, 45, 142, 51); }
        wd.textContent = [...word].map(ch => got.has(ch) || over ? ch : '_').join('');
        inf.innerHTML = (hint ? 'Подсказка: <b>' + esc(hint) + '</b> · ' : '') + 'ошибок ' + n + ' из 7';
      };
      const guess = k => {
        if (over || k.length !== 1 || got.has(k) || bad.has(k)) return;
        if (word.includes(k)) { got.add(k); keys[k].className = 'g'; } else { bad.add(k); keys[k].className = 'x'; }
        if ([...word].every(ch => got.has(ch))) { over = true; paint(); ctx.match(ctx.mode === 'hot' ? 'draw' : 'win', ctx.mode === 'hot' ? 'Слово угадано!' : 'Угадали: ' + word.toUpperCase()); return; }
        if (bad.size >= 7) { over = true; paint(); ctx.match(ctx.mode === 'hot' ? 'draw' : 'loss', 'Было слово: ' + word.toUpperCase()); return; }
        paint();
      };
      physKeys(ctx, guess); paint();
    };
    if (ctx.mode === 'hot') {
      const inp = h('input', { id: 'hw', type: 'password', placeholder: 'Слово (только буквы)', autocomplete: 'off' }), hi = h('input', { id: 'hh', placeholder: 'Подсказка (можно пусто)', style: { marginTop: '8px' } });
      el.append(h('div', { class: 'card', style: { width: 'min(100%,380px)' } }, h('b', null, 'Игрок 1 загадывает слово'), h('p', { class: 'hint' }, 'Второй игрок пусть отвернётся.'), inp, hi, h('button', { class: 'go', onclick: () => { const w = inp.value.trim().toLowerCase().replace(/ё/g, 'е'); if (!/^[а-я]{3,15}$/.test(w)) return ctx.toast('Нужно слово из 3–15 русских букв'); play(w, hi.value.trim()); } }, 'Загадать')));
    } else { const [w, c] = pick(bank); play(w, c); }
  }
});

function whoOnline(el, ctx) {
  const net = ctx.net, N = net.seats.length, me = Math.max(0, net.seat), watching = net.watching, nm = i => net.seats[i].name;
  let phase = 'write', sub = {}, Q = [], k = 0, votes = {}, res = null, over = false, deadline = Date.now() + 120000, sent = '';
  const sc = Array(N).fill(0), box = h('div', { class: 'card', style: { width: 'min(100%,420px)', textAlign: 'center' } }); el.append(box);
  const all = [...Array(N).keys()];
  const pending = () => phase === 'write' ? all.filter(i => !(i in sub)) : phase === 'guess' ? all.filter(i => i !== Q[k].a && !(i in votes)) : [];
  const setPhase = (p, sec) => { phase = p; deadline = Date.now() + sec * 1000; };
  const finish = () => { over = true; phase = 'over'; const ranks = sc.map(v => sc.filter(w => w > v).length); render(); ctx.ranks(ranks, 'Игра окончена'); };
  const apply = (s, a) => {
    if (over || s < 0 || s >= N) return;
    if (phase === 'write' && a.w && !(s in sub)) {
      sub[s] = (Array.isArray(a.w) ? a.w : []).slice(0, 2).map(t => String(t).trim().slice(0, 140)).filter(Boolean);
      if (!pending().length) { Q = shuffle(all.flatMap(i => sub[i].map(t => ({ t, a: i })))); if (!Q.length) return finish(); k = 0; votes = {}; setPhase('guess', 40); }
    } else if (phase === 'guess' && a.g != null && s !== Q[k].a && !(s in votes)) {
      votes[s] = a.g | 0;
      if (!pending().length) { const right = Object.keys(votes).map(Number).filter(i => votes[i] === Q[k].a); right.forEach(i => sc[i]++); if (!right.length) sc[Q[k].a]++; res = { right, a: Q[k].a }; setPhase('reveal', 5); }
    } else if (phase === 'reveal' && a.nx === k) { k++; if (k >= Q.length) return finish(); votes = {}; res = null; setPhase('guess', 40); }
    render();
  };
  const act = a => { if (!watching) net.send(a); };
  const render = () => {
    box.innerHTML = '';
    const left = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
    if (phase === 'write') {
      if (me in sub || watching) box.append(h('b', null, 'Фразы получены'), h('p', { class: 'hint' }, 'Ждём остальных: ' + Object.keys(sub).length + ' из ' + N));
      else { const a = h('textarea', { placeholder: 'Фраза 1: цитата, факт о себе, смешной случай', maxlength: 140 }), b2 = h('textarea', { placeholder: 'Фраза 2', maxlength: 140, style: { marginTop: '8px' } });
        box.append(h('b', null, 'Напишите две фразы о себе'), h('p', { class: 'hint' }, 'Остальные будут угадывать автора. Осталось ' + left + ' с'), a, b2, h('button', { class: 'go', type: 'button', style: { marginTop: '10px' }, onclick: () => act({ w: [a.value, b2.value] }) }, 'Готово')); }
    } else if (phase === 'guess' || phase === 'reveal') {
      const q = Q[k];
      box.append(h('small', { class: 'hint' }, 'Фраза ' + (k + 1) + ' из ' + Q.length), h('div', { style: { fontSize: '22px', fontWeight: 700, margin: '14px 0', overflowWrap: 'anywhere' } }, '«' + q.t + '»'));
      if (phase === 'guess') {
        if (q.a === me && !watching) box.append(h('p', { class: 'hint' }, 'Это ваша фраза. Не выдавайте себя 🙂'));
        else if (me in votes || watching) box.append(h('p', { class: 'hint' }, 'Ответ принят. Проголосовало ' + Object.keys(votes).length + ' из ' + (N - 1)));
        else { const g = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px', justifyContent: 'center' } }); all.filter(i => i !== me).forEach(i => g.append(h('button', { class: 'nb', type: 'button', style: { flex: 'none' }, onclick: () => act({ g: i }) }, nm(i)))); box.append(h('p', { class: 'hint' }, 'Кто это написал? Осталось ' + left + ' с'), g); }
      } else box.append(h('b', { style: { fontSize: '20px' } }, 'Это написал(а) ' + nm(res.a)), h('p', { class: 'hint' }, res.right.length ? 'Угадали: ' + res.right.map(nm).join(', ') : 'Никто не угадал — очко автору'));
    } else box.append(h('div', { style: { fontSize: '48px' } }, '🏆'), h('b', null, all.filter(i => sc[i] === Math.max(...sc)).map(nm).join(', ') + ' — лучше всех знает друзей'));
    if (phase !== 'write') box.append(h('p', { class: 'hint' }, all.map(i => nm(i) + ': ' + sc[i]).join(' · ')));
  };
  net.onAct(apply); net.onLeft(() => { });
  ctx.score(''); render();
  const tick = setInterval(() => {
    if (!ctx.alive) return clearInterval(tick); if (over) return;
    const late = Date.now() > deadline, pend = pending(), key = phase + k + ':' + pend.join(',');
    if (late && pend.includes(me) && !watching && sent !== 'me' + key) { sent = 'me' + key; net.send(phase === 'write' ? { w: [] } : { g: -1 }); }
    if (net.isHost && sent.indexOf('h' + key) < 0) { const gone = pend.filter(i => net.seats[i].left || net.seats[i].bot); if (gone.length) { sent += 'h' + key; gone.forEach(i => net.botSend(i, phase === 'write' ? { w: [] } : { g: -1 })); } }
    if (phase === 'reveal' && late && !watching && sent !== 'nx' + k && (net.isHost || Date.now() > deadline + 4000)) { sent = 'nx' + k; net.send({ nx: k }); }
  }, 1000);
}

game({
  id: 'whosaid', name: 'Угадай, кто сказал', like: 'для компании', cat: 'party', icon: '💬', c1: '#ff99c8', c2: '#a06cd5', players: '3–8 игроков', modes: ['live'],
  rules: ['Каждый по очереди тайно пишет две фразы: любимую цитату, факт о себе, смешной случай.', 'Потом фразы показываются по одной в случайном порядке, все пытаются угадать автора.', 'Ведущий отмечает, кто угадал, — каждому по очку. Автору очко, если его не угадал никто.', 'В приложении на любую фразу можно будет пожаловаться — она сразу скроется.'],
  run(el, ctx) {
    if (ctx.net) return whoOnline(el, ctx);
    ctx.score('');
    namesSetup(el, { min: 3, max: 8, def: 4, title: 'Кто играет?', note: 'Телефон будут передавать по кругу.' }, names => {
      const Q = [], sc = names.map(() => 0);
      const scr = (...k) => { el.innerHTML = ''; el.append(h('div', { class: 'card', style: { width: 'min(100%,420px)', textAlign: 'center' } }, ...k)); };
      const write = i => {
        if (i >= names.length) return show(shuffle(Q), 0);
        scr(h('b', { style: { fontSize: '18px' } }, 'Передайте телефон: ' + names[i]), h('button', { class: 'go', onclick: () => {
          const a = h('textarea', { id: 'w1', placeholder: 'Фраза 1', maxlength: 140, style: { marginTop: '8px' } }), b = h('textarea', { id: 'w2', placeholder: 'Фраза 2', maxlength: 140, style: { marginTop: '8px' } });
          scr(h('b', null, names[i] + ', напишите две фразы'), h('p', { class: 'hint' }, 'Никто не должен видеть'), a, b, h('button', { class: 'go', onclick: () => { [a, b].forEach(t => t.value.trim() && Q.push({ t: t.value.trim(), a: i })); write(i + 1); } }, 'Готово, передать дальше'));
        } }, 'Это я'));
      };
      const show = (qs, k) => {
        if (k >= qs.length) { const best = Math.max(...sc); scr(h('div', { style: { fontSize: '48px' } }, '🏆'), h('b', { style: { fontSize: '19px' } }, names.filter((_, i) => sc[i] === best).join(', ') + ' — лучше всех знает друзей'), h('p', { class: 'hint' }, names.map((n, i) => n + ': ' + sc[i]).join(' · ')), h('button', { class: 'go', onclick: () => ctx.match('draw', 'Игра окончена') }, 'Завершить')); return; }
        const q = qs[k], right = new Set();
        const chips = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px', justifyContent: 'center', marginTop: '10px' } });
        const dc = () => { chips.innerHTML = ''; names.forEach((n, i) => { if (i === q.a) return; chips.append(h('button', { class: 'nb', style: { flex: 'none', background: right.has(i) ? 'var(--ok)' : '', color: right.has(i) ? '#fff' : '' }, onclick: () => { right.has(i) ? right.delete(i) : right.add(i); dc(); } }, n)); }); };
        scr(h('small', { class: 'hint' }, 'Фраза ' + (k + 1) + ' из ' + qs.length), h('div', { style: { fontSize: '22px', fontWeight: 700, margin: '14px 0', overflowWrap: 'anywhere' } }, '«' + q.t + '»'), h('p', { class: 'hint' }, 'Каждый называет автора вслух. Отметьте, кто угадал:'), chips,
          h('button', { class: 'go', onclick: () => { right.forEach(i => sc[i]++); if (!right.size) sc[q.a]++; scr(h('b', { style: { fontSize: '20px' } }, 'Это написал(а) ' + names[q.a]), h('p', { class: 'hint' }, right.size ? 'Угадали: ' + [...right].map(i => names[i]).join(', ') : 'Никто не угадал — очко автору'), h('button', { class: 'go', onclick: () => show(qs, k + 1) }, 'Дальше')); } }, 'Показать автора'));
        dc();
      };
      write(0);
    });
  }
});
