// Ключи Firebase открытые по замыслу: безопасность держится на правилах Firestore.
export const FIREBASE = {
  "apiKey": "AIzaSyAyhHz1SYcTlKdRFBhsA3eMvSTLFrLx40E",
  "authDomain": "barsu-student.firebaseapp.com",
  "projectId": "barsu-student",
  "storageBucket": "barsu-student.firebasestorage.app",
  "messagingSenderId": "47952928606",
  "appId": "1:47952928606:android:7c28f5739f51668d3f79cf"
};
export const OWNER_EMAIL = "vgostahunorberta362@gmail.com";
